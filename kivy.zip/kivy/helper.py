from PIL import Image, ImageDraw, ImageFont
import os

# Make sure assets folder exists
os.makedirs("assets", exist_ok=True)

# Font (replace with any .ttf available on your system if Arial not found)
try:
    font = ImageFont.truetype("arial.ttf", 200)  # Windows usually has Arial
except:
    font = ImageFont.load_default()

# Image size
img_size = (256, 256)

# Create base "E"
base = Image.new("RGBA", img_size, (255, 255, 255, 0))  # transparent background
draw = ImageDraw.Draw(base)

# Use textbbox to measure size of "E"
bbox = draw.textbbox((0, 0), "E", font=font)
w, h = bbox[2] - bbox[0], bbox[3] - bbox[1]

# Draw text centered
draw.text(((img_size[0] - w) // 2, (img_size[1] - h) // 2),
          "E", fill=(0, 0, 0, 255), font=font)

# Save rotated versions
angles = [0, 90, 180, 270]
for angle in angles:
    rotated = base.rotate(angle, expand=True)
    rotated.save(f"assets/tumbling_e_{angle}.png")
    print(f"Saved: assets/tumbling_e_{angle}.png")
