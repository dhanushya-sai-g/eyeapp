import os
import string
from pymongo import MongoClient
from dotenv import load_dotenv
from kivy.app import App
from kivy.uix.textinput import TextInput
from kivy.core.window import Window
from kivy.uix.widget import Widget
from kivymd.uix.button import MDFlatButton
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.properties import StringProperty, NumericProperty
from kivymd.uix.selectioncontrol import MDCheckbox
from kivymd.app import MDApp
from kivy.properties import BooleanProperty, StringProperty, NumericProperty # Added NumericProperty
from kivy.clock import Clock
from kivymd.uix.progressbar import MDProgressBar # For the progress bar
from kivymd.toast import toast # For simple "Correct!" / "Incorrect!"
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDTextButton, MDRaisedButton
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.textfield import MDTextField
from kivymd.uix.label import MDLabel
from kivy.properties import ObjectProperty
from kivy.uix.scrollview import ScrollView
from kivy.uix.gridlayout import GridLayout
from kivymd.toast import toast
from kivymd.uix.menu import MDDropdownMenu
from kivymd.uix.card import MDCard
from kivy.metrics import dp
from kivy.uix.image import Image as KivyImage
from kivy.uix.scrollview import ScrollView
from kivy.uix.boxlayout import BoxLayout
from kivymd.uix.boxlayout import MDBoxLayout
from kivy.uix.gridlayout import GridLayout
from kivymd.uix.button import MDIconButton
from kivy.clock import Clock
import re
import unicodedata
import regex as regx 
from kivymd.uix.gridlayout import MDGridLayout
import random
from tamil.utf8 import get_letters
from kivy.uix.floatlayout import FloatLayout
from kivy.graphics import Color, Rectangle, Rotate
from pdf2image import convert_from_path
import fitz  # PyMuPDF
from PIL import Image
import time
from kivy.core.text import LabelBase

# Register fonts (do this once, e.g., at the start of your app)

LabelBase.register(name="TamilFont", fn_regular="fonts/NotoSansTamil-Regular.ttf")
LabelBase.register(name="HindiFont", fn_regular="fonts/NotoSansDevanagari-Regular.ttf")
LabelBase.register(name="TeluguFont", fn_regular="fonts/NotoSansTelugu-Regular.ttf")
# Load environment variables from .env
load_dotenv()

# MongoDB setup
connection_string = os.getenv("MONGO_URI")
if not connection_string:
    connection_string="mongodb+srv://dhanushya:frooti@eye-doc-application.c6dvx4u.mongodb.net/"

client = MongoClient(connection_string)
db = client['EyeDoctor']
collection = db['Credentials']





class LoginScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = MDBoxLayout(orientation='vertical', padding=40, spacing=20)

        layout.add_widget(MDLabel(text="Login", halign="center", font_style="H4"))
        self.email = MDTextField(hint_text="Email", size_hint_x=None, width=300, pos_hint={"center_x": 0.5})
        self.password = MDTextField(hint_text="Password", password=True, size_hint_x=None, width=300, pos_hint={"center_x": 0.5})

        layout.add_widget(self.email)
        layout.add_widget(self.password)

        login_btn = MDRaisedButton(text="Login", size_hint_x=None, width=300, pos_hint={"center_x": 0.5})
        login_btn.bind(on_release=self.do_login)
        layout.add_widget(login_btn)

        switch_btn = MDTextButton(text="Don't have an account? Sign up", pos_hint={"center_x": 0.5})
        switch_btn.bind(on_release=self.go_to_signup)
        layout.add_widget(switch_btn)

        self.add_widget(layout)

    def do_login(self, instance):
        user = collection.find_one({"email": self.email.text, "password": self.password.text})
        MDApp.get_running_app().email = str(self.email.text)
        if user:
            MDApp.get_running_app().user_id = str(user["_id"])
            MDApp.get_running_app().user_name = user["name"]  # Store user name
            self.manager.current = 'main'  # Navigate to main screen
        else:
            toast("Invalid email or password.")

    def go_to_signup(self, instance):
        self.manager.current = 'signup'


class SignupScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = MDBoxLayout(orientation='vertical', padding=40, spacing=20)
        layout.add_widget(MDLabel(text="Sign Up", halign="center", font_style="H4"))

        self.name_field = MDTextField(hint_text="Name", size_hint_x=None, width=300, pos_hint={"center_x": 0.5})
        layout.add_widget(self.name_field)

        self.email_field = MDTextField(hint_text="Email", size_hint_x=None, width=300, pos_hint={"center_x": 0.5})
        layout.add_widget(self.email_field)

        self.password_field = MDTextField(hint_text="Password", password=True, size_hint_x=None, width=300, pos_hint={"center_x": 0.5})
        layout.add_widget(self.password_field)

        self.confirm_password_field = MDTextField(hint_text="Confirm Password", password=True, size_hint_x=None, width=300, pos_hint={"center_x": 0.5})
        layout.add_widget(self.confirm_password_field)

        signup_btn = MDRaisedButton(text="Sign Up", size_hint_x=None, width=300, pos_hint={"center_x": 0.5})
        signup_btn.bind(on_release=self.do_signup)
        layout.add_widget(signup_btn)

        switch_btn = MDTextButton(text="Already have an account? Login", pos_hint={"center_x": 0.5})
        switch_btn.bind(on_release=self.go_to_login)
        layout.add_widget(switch_btn)

        self.add_widget(layout)

    def do_signup(self, instance):
        if self.password_field.text != self.confirm_password_field.text:
            self.show_alert_dialog("Passwords do not match!")
            return
        
        document = {
            "name": self.name_field.text,
            "email": self.email_field.text,
            "password": self.password_field.text
        }
        
        result = collection.insert_one(document)
        inserted_id = str(result.inserted_id)
        MDApp.get_running_app().user_id = inserted_id
        MDApp.get_running_app().user_name = self.name_field.text  # Store user name

        self.show_alert_dialog("Signup successful! Click OK to login.", self.go_to_login)

    def show_alert_dialog(self, message, on_ok_callback=None):
        self.dialog = MDDialog(
            title="Notification",
            text=message,
            buttons=[
                MDTextButton(
                    text="OK",
                    on_release=lambda x: self.close_dialog(on_ok_callback)
                ),
            ],
        )
        self.dialog.open()
        Clock.schedule_once(lambda dt: self.close_dialog(on_ok_callback), 3)

    def close_dialog(self, on_ok_callback):
        if on_ok_callback:
            on_ok_callback(None)
        self.dialog.dismiss()

    def go_to_login(self, instance):
        self.manager.current = 'login'


# Custom BoxLayout to add background color
class ColoredBoxLayout(MDBoxLayout):
    def __init__(self, bg_color, **kwargs):
        super().__init__(**kwargs)
        self.bg_color = bg_color
        with self.canvas.before:
            Color(*self.bg_color)
            self.rect = Rectangle(pos=self.pos, size=self.size)
        self.bind(pos=self._update_rect, size=self._update_rect)

    def _update_rect(self, *args):
        self.rect.pos = self.pos
        self.rect.size = self.size

class MainScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        # Root layout with translucent bright blue background
        self.root_layout = MDBoxLayout(
            orientation='vertical', 
            padding=20, 
            spacing=20,
            size_hint=(1, 1)  # fill the screen
        )

        with self.root_layout.canvas.before:
            Color(0, 0.486, 1, 0.24)  # translucent bright blue
            self.rect = Rectangle(pos=self.root_layout.pos, size=self.root_layout.size)
        self.root_layout.bind(pos=self._update_rect, size=self._update_rect)

        # Add the root_layout directly to the screen (no ScrollView)
        self.add_widget(self.root_layout)

        # Add the cards directly to the root_layout
        self._create_welcome_section()
        self._create_tests_section()

    def _update_rect(self, *args):
        self.rect.pos = self.root_layout.pos
        self.rect.size = self.root_layout.size

    def _create_welcome_section(self):
        welcome_card = MDCard(
            orientation='vertical',
            padding=[20, 30, 20, 30],
            size_hint=(1, None),
            height=180,
            md_bg_color=(0.2, 0.6, 0.86, 1),
            radius=[20, 20, 20, 20],
            elevation=2,
        )

        self.welcome_label = MDLabel(
            text="",
            halign='center',
            font_style='H6',
            theme_text_color="Custom",
            text_color=(1, 1, 1, 1),
        )
        welcome_card.add_widget(self.welcome_label)
        self.root_layout.add_widget(welcome_card)

    def _create_tests_section(self):
        tests_card = MDCard(
            orientation='vertical',
            padding=[20, 30, 20, 30],
            size_hint=(1, None),
            height=600,
            radius=[20, 20, 20, 20],
            elevation=2,
            md_bg_color=(1, 1, 1, 1),
        )

        buttons_layout = MDBoxLayout(
            orientation='vertical',
            spacing=15,
            size_hint_y=None,
            height=395,
            padding=[0, 10, 0, 10],
        )

        test_names = [
            "Distance Vision Test",
            "Near Vision Test",
            "Color Vision Test",
            "Contrast Sensitivity Test",
            "Amsler Grid Test",
            "Stereopsis Test",
            "Scores"
        ]

        for name in test_names:
            test_btn = MDRaisedButton(
                text=name,
                size_hint=(1, None),
                height=50,
                md_bg_color=(0.2, 0.6, 0.86, 1),
                text_color=(1, 1, 1, 1),
            )
            test_btn.bind(on_release=self.on_test_button_press)
            buttons_layout.add_widget(test_btn)

        tests_card.add_widget(buttons_layout)
        self.root_layout.add_widget(tests_card)

    def on_enter(self):
        user_name = MDApp.get_running_app().user_name
        self.welcome_label.text = f"Hello {user_name}!\nWelcome to EyeDoc"

    def on_test_button_press(self, instance):
        screen_map = {
            "Distance Vision Test": 'distance_vision_test',
            "Near Vision Test": 'near_vision_test',
            "Color Vision Test": 'color_vision_test',
            "Contrast Sensitivity Test": 'contrast_sensitivity_test',
            "Amsler Grid Test": 'amsler_grid_test',
            "Stereopsis Test": 'stereopsis_test',
            "Scores": 'scores',
        }
        self.manager.current = screen_map.get(instance.text, self.manager.current)



class LeftEyeTestScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.score = 0
        self.current_index = 0
        self.user_answers = []
        self.correct_answers = ['12', '8', '29', '5', '3', '15', '74','6','45','5','7','16','73','','','26','42']  # Replace with actual correct answers

        self.image_paths = self.convert_pdf_to_images("color_vision.pdf")
        
        self.layout = MDBoxLayout(orientation='vertical', padding=20, spacing=10)
        self.scroll = ScrollView()
        self.scroll.add_widget(self.layout)
        self.add_widget(self.scroll)

        # Back button
        back_button = MDIconButton(icon="arrow-left", pos_hint={"center_x": 0.1, "center_y": 0.9})
        back_button.bind(on_release=self.go_back)
        self.layout.add_widget(back_button)

        self.layout.add_widget(MDLabel(text="Left Eye Color Vision Test", halign="center", font_style="H6"))

        # Question preview label
        self.preview_label = MDLabel(text="", halign="center", theme_text_color="Secondary")
        self.layout.add_widget(self.preview_label)

        # Image display
        self.image_widget = KivyImage(size_hint_y=1.5, allow_stretch=True, keep_ratio=True)
        self.layout.add_widget(self.image_widget)

        # Input field
        self.input_field = MDTextField(hint_text="Enter the number you see", mode="rectangle")
        self.layout.add_widget(self.input_field)

        # Submit button
        self.submit_button = MDRaisedButton(text="Submit", on_release=self.check_answer)
        self.layout.add_widget(self.submit_button)

        self.update_question()

    def on_enter(self):
        self.show_instructions()

    def show_instructions(self):
        instruction_text = "Instructions for the Left Eye Color Vision Test:\n\n" \
                           "1. Please cover your right eye.\n" \
                           "2. Focus on the provided images.\n" \
                           "3. Enter the numbers visible to you on the screen.\n" \
                           "4. If no number is visible, leave the textbox blank."

        self.dialog = MDDialog(
            title="Instructions: Attend the right eye test before attending the left eye test",
            text=instruction_text,
            buttons=[MDTextButton(text="OK", on_release=self.close_dialog)],
        )
        self.dialog.open()


    def close_dialog(self, *args):
        self.dialog.dismiss()

    def convert_pdf_to_images(self, pdf_path, output_folder="pdf_images"):
        os.makedirs(output_folder, exist_ok=True)
        doc = fitz.open(pdf_path)
        image_paths = []

        for i, page in enumerate(doc):
            pix = page.get_pixmap()
            img_path = os.path.join(output_folder, f"page_{i + 1}.png")
            pix.save(img_path)
            image_paths.append(img_path)

        return image_paths

    def update_question(self):
        if self.current_index < len(self.image_paths):
            self.image_widget.source = self.image_paths[self.current_index]
            self.input_field.text = ""
            self.preview_label.text = f"Question {self.current_index + 1} of {len(self.correct_answers)}"
        else:
            self.end_quiz()

    def check_answer(self, instance):
        user_input = self.input_field.text.strip()
        self.user_answers.append(user_input)

        if self.current_index < len(self.correct_answers):
            if user_input == self.correct_answers[self.current_index]:
                self.score += 1

        self.current_index += 1
        self.update_question()

    def go_back(self, instance):
        self.manager.current = 'color_vision_test'

    def finish_and_go_back(self, *args):
        self.dialog.dismiss()
        self.manager.current = 'color_vision_test'

    def end_quiz(self):
        app = MDApp.get_running_app()
        app.left_eye_score = self.score

        # Save score to MongoDB
        if self.score == len(self.correct_answers):
            remark = "Excellent"
            result_text = f"You scored {self.score} out of {len(self.correct_answers)}\nGreat news—your colour vision is perfectly normal.\nYou correctly identified all the test patterns, so there’s no sign of red-green colour deficiency."
        else:
            remark = "Needs Attention"
            result_text = f"You scored {self.score} out of {len(self.correct_answers)}\nHeads up!\nIt looks like you had trouble with some of the colour patterns in the test. This might mean you have a red-green colour vision deficiency. It’s quite common, but to be sure, please consider seeing an eye specialist."
            collection.update_one(
                        {"email": app.email},
                        {"$set": {
                            "Color_vision_results.left_eye_score": self.score,
                            "Color_vision_results.left_eye_remark": remark
                        }},
                        upsert=True # Creates the document if it doesn't exist
            )

        
        self.dialog = MDDialog(
            title="Test Complete",
            text=result_text
        )
        self.go_back_no_args()
        self.dialog.open()
        
    def go_back_no_args(self):
        self.manager.current = 'color_vision_test'

        
    
        
        



class RightEyeTestScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.score = 0
        self.current_index = 0
        self.user_answers = []
        self.correct_answers = ['12', '8', '29', '5', '3', '15', '74','6','45','5','7','16','73','','','26','42']

        self.image_paths = self.convert_pdf_to_images("color_vision.pdf")

        self.layout = MDBoxLayout(orientation='vertical', padding=20, spacing=10)
        self.scroll = ScrollView()
        self.scroll.add_widget(self.layout)
        self.add_widget(self.scroll)

        # Back button
        back_button = MDIconButton(icon="arrow-left", pos_hint={"center_x": 0.1, "center_y": 0.9})
        back_button.bind(on_release=self.go_back)
        self.layout.add_widget(back_button)

        self.layout.add_widget(MDLabel(text="Right Eye Color Vision Test", halign="center", font_style="H6"))

        # Question preview label
        self.preview_label = MDLabel(text="", halign="center", theme_text_color="Secondary")
        self.layout.add_widget(self.preview_label)

        # Image display
        self.image_widget = KivyImage(size_hint_y=1.5, allow_stretch=True, keep_ratio=True)
        self.layout.add_widget(self.image_widget)

        # Input field
        self.input_field = MDTextField(hint_text="Enter the number you see", mode="rectangle")
        self.layout.add_widget(self.input_field)

        # Submit button
        self.submit_button = MDRaisedButton(text="Submit", on_release=self.check_answer)
        self.layout.add_widget(self.submit_button)

        self.update_question()

    def on_enter(self):
        self.show_instructions()

    def show_instructions(self):
        instruction_text = "Instructions for the Right Eye Color Vision Test:\n\n" \
                           "1. Please cover your left eye.\n" \
                           "2. Focus on the provided images.\n" \
                           "3. Enter the numbers visible to you on the screen.\n" \
                           "4. If no number is visible, leave the textbox blank."
        self.dialog = MDDialog(
            title="Instructions",
            text=instruction_text,
            buttons=[MDTextButton(text="OK", on_release=self.close_dialog)],
        )
        self.dialog.open()

    def close_dialog(self, *args):
        self.dialog.dismiss()

    def convert_pdf_to_images(self, pdf_path, output_folder="pdf_images"):
        os.makedirs(output_folder, exist_ok=True)
        doc = fitz.open(pdf_path)
        image_paths = []

        for i, page in enumerate(doc):
            pix = page.get_pixmap()
            img_path = os.path.join(output_folder, f"page_{i + 1}.png")
            pix.save(img_path)
            image_paths.append(img_path)

        return image_paths

    def update_question(self):
        if self.current_index < len(self.image_paths):
            self.image_widget.source = self.image_paths[self.current_index]
            self.input_field.text = ""
            self.preview_label.text = f"Question {self.current_index + 1} of {len(self.correct_answers)}"
        else:
            self.end_quiz()

    def check_answer(self, instance):
        user_input = self.input_field.text.strip()
        self.user_answers.append(user_input)

        if self.current_index < len(self.correct_answers):
            if user_input == self.correct_answers[self.current_index]:
                self.score += 1

        self.current_index += 1
        self.update_question()

    def go_back(self, instance):
        self.manager.current = 'color_vision_test'

    def go_back_no_args(self):
        self.manager.current = 'color_vision_test'

    def end_quiz(self):
        app = MDApp.get_running_app()
        app.right_eye_score = self.score

        # Save score to MongoDB


        if self.score == len(self.correct_answers):
            remark = "Excellent"
            result_text = f"You scored {self.score} out of {len(self.correct_answers)}\nGreat news—your colour vision is perfectly normal.\nYou correctly identified all the test patterns, so there’s no sign of red-green colour deficiency."
        else:
            remark = "Needs Attention"
            result_text = f"You scored {self.score} out of {len(self.correct_answers)}\nHeads up!\nIt looks like you had trouble with some of the colour patterns in the test. This might mean you have a red-green colour vision deficiency. It’s quite common, but to be sure, please consider seeing an eye specialist."

            collection.update_one(
                        {"email": app.email},
                        {"$set": {
                            "Color_vision_results.right_eye_score": self.score,
                            "Color_vision_results.right_eye_remark": remark
                        }},
                        upsert=True # Creates the document if it doesn't exist
            )


        self.dialog = MDDialog(
            title="Test Complete: You may now attend the left eye test",
            text=result_text
        )
        self.go_back_no_args()
        self.dialog.open()


        
    


class ColorVisionTestScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        theme_cls = MDApp.get_running_app().theme_cls
        is_light = theme_cls.theme_style == "Light"

        # Root layout with translucent bright blue background (similar style to ContrastSensitivityTestScreen)
        self.root_layout = MDBoxLayout(
            orientation='vertical',
            padding=[20, 40, 20, 30],
            spacing=30,
            size_hint=(1, 1)
        )

        with self.root_layout.canvas.before:
            Color(0, 0.486, 1, 0.24)  # translucent bright blue background
            self.rect = Rectangle(pos=self.root_layout.pos, size=self.root_layout.size)
        self.root_layout.bind(pos=self._update_rect, size=self._update_rect)

        # Top bar with back button
        top_bar = MDBoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=dp(56),
            padding=[0, 0, 0, 0],
            md_bg_color=[0, 0, 0, 0]
        )
        back_button = MDIconButton(
            icon="arrow-left",
            size_hint=(None, None),
            icon_size="20dp",
            theme_icon_color="Custom",
            icon_color=[0, 0, 0, 1] if is_light else [1, 1, 1, 1],
            md_bg_color=[0.9, 0.9, 0.9, 0.15] if is_light else [0.3, 0.3, 0.3, 0.15]
        )
        back_button.bind(on_release=self.go_back)
        top_bar.add_widget(back_button)
        self.root_layout.add_widget(top_bar)

        # Title labels with improved font styles
        self.root_layout.add_widget(MDLabel(
            text="Color Vision Test",
            halign="center",
            font_style="H5",        # Slightly better than Subtitle1, fits title well
            size_hint_y=None,
            height=dp(60),
            theme_text_color="Primary",
            font_name="Roboto"
        ))
        self.root_layout.add_widget(MDLabel(
            text="Attend the right eye test before attending the left eye test.",
            halign="center",
            font_style="Body2",     # Cleaner and readable caption style
            size_hint_y=None,
            height=dp(60),
            theme_text_color="Primary",
            font_name="Roboto"
        ))

        # Card-style container with subtle shadow for buttons
        card = MDCard(
            orientation='vertical',
            padding=dp(15),
            spacing=dp(20),
            size_hint=(0.85, None),
            height=dp(150),
            pos_hint={'center_x': 0.5},
            md_bg_color=[1, 1, 1, 1] if is_light else [0.25, 0.25, 0.25, 1],
            radius=[12, 12, 12, 12],
            elevation=2
        )

        # Right Eye Test Button
        right_eye_button = MDRaisedButton(
            text="Right Eye Test",
            size_hint=(1, None),
            height=dp(48),
            md_bg_color=theme_cls.primary_color,
            text_color=[1, 1, 1, 1],
            font_size="15sp",
            font_name="Roboto",
            line_color=[0.7, 0.7, 0.7, 0.25] if is_light else [0.5, 0.5, 0.5, 0.25]
        )
        right_eye_button.bind(on_release=lambda x: self.start_test('right_eye_test'))
        card.add_widget(right_eye_button)

        # Left Eye Test Button
        left_eye_button = MDRaisedButton(
            text="Left Eye Test",
            size_hint=(1, None),
            height=dp(48),
            md_bg_color=theme_cls.primary_color,
            text_color=[1, 1, 1, 1],
            font_size="15sp",
            font_name="Roboto",
            line_color=[0.7, 0.7, 0.7, 0.25] if is_light else [0.5, 0.5, 0.5, 0.25]
        )
        left_eye_button.bind(on_release=lambda x: self.start_test('left_eye_test'))
        card.add_widget(left_eye_button)

        self.root_layout.add_widget(card)
        self.add_widget(self.root_layout)

    def _update_rect(self, *args):
        self.rect.pos = self.root_layout.pos
        self.rect.size = self.root_layout.size

    def go_back(self, instance):
        self.manager.current = 'main'

    def start_test(self, test_screen_name):
        self.manager.current = test_screen_name


        
class ContrastSensitivityTestScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        theme_cls = MDApp.get_running_app().theme_cls
        is_light = theme_cls.theme_style == "Light"

        # Root layout with translucent bright blue background (like MainScreen)
        self.root_layout = MDBoxLayout(
            orientation='vertical',
            padding=[20, 40, 20, 30],
            spacing=30,
            size_hint=(1, 1)
        )

        with self.root_layout.canvas.before:
            Color(0, 0.486, 1, 0.24)  # translucent bright blue
            self.rect = Rectangle(pos=self.root_layout.pos, size=self.root_layout.size)
        self.root_layout.bind(pos=self._update_rect, size=self._update_rect)

        # Top bar with back button
        top_bar = MDBoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=dp(56),
            padding=[0, 0, 0, 0],
            md_bg_color=[0, 0, 0, 0]
        )
        back_button = MDIconButton(
            icon="arrow-left",
            size_hint=(None, None),
            icon_size="20dp",
            theme_icon_color="Custom",
            icon_color=[0, 0, 0, 1] if is_light else [1, 1, 1, 1],
            md_bg_color=[0.9, 0.9, 0.9, 0.15] if is_light else [0.3, 0.3, 0.3, 0.15]
        )
        back_button.bind(on_release=self.go_back)
        top_bar.add_widget(back_button)
        self.root_layout.add_widget(top_bar)

        # Title labels
        self.root_layout.add_widget(MDLabel(
            text="Contrast Sensitivity Test",
            halign="center",
            font_style="H5",
            size_hint_y=None,
            height=dp(60),
            theme_text_color="Primary",
            font_name="Roboto"
        ))
        self.root_layout.add_widget(MDLabel(
            text="Attend the right eye test before attending the left eye test.",
            halign="center",
            font_style="Body1",
            size_hint_y=None,
            height=dp(60),
            theme_text_color="Primary",
            font_name="Roboto"
        ))

        # Card-style container with subtle shadow for buttons
        card = MDCard(
            orientation='vertical',
            padding=dp(15),
            spacing=dp(20),
            size_hint=(0.85, None),
            height=dp(150),
            pos_hint={'center_x': 0.5},
            md_bg_color=[1, 1, 1, 1] if is_light else [0.25, 0.25, 0.25, 1],
            radius=[12, 12, 12, 12],
            elevation=2 # subtle shadow effect
        )

        # Right Eye Test Button
        right_eye_button = MDRaisedButton(
            text="Right Eye Test",
            size_hint=(1, None),
            height=dp(48),
            md_bg_color=theme_cls.primary_color,
            text_color=[1, 1, 1, 1],
            font_size="15sp",
            font_name="Roboto",
            line_color=[0.7, 0.7, 0.7, 0.25] if is_light else [0.5, 0.5, 0.5, 0.25]
        )
        right_eye_button.bind(on_release=lambda x: self.start_test('right_eye_test_contrast'))
        card.add_widget(right_eye_button)

        # Left Eye Test Button
        left_eye_button = MDRaisedButton(
            text="Left Eye Test",
            size_hint=(1, None),
            height=dp(48),
            md_bg_color=theme_cls.primary_color,
            text_color=[1, 1, 1, 1],
            font_size="15sp",
            font_name="Roboto",
            line_color=[0.7, 0.7, 0.7, 0.25] if is_light else [0.5, 0.5, 0.5, 0.25]
        )
        left_eye_button.bind(on_release=lambda x: self.start_test('left_eye_test_contrast'))
        card.add_widget(left_eye_button)

        self.root_layout.add_widget(card)
        self.add_widget(self.root_layout)

    def _update_rect(self, *args):
        self.rect.pos = self.root_layout.pos
        self.rect.size = self.root_layout.size

    def go_back(self, instance):
        self.manager.current = 'main'

    def start_test(self, test_screen_name):
        self.manager.current = test_screen_name


class LeftEyeTestScreenContrast(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.level = None
        self.score = 0
        self.question_points = [round(0.15 * i, 2) for i in range(16)]
        self.current_index = 0
        self.user_answers = []
        self.correct_answers = [
            'VRS', 'KDR', 'NHC', 'SOK', 'SCN', 'OZV', 'CNH', 'ZOK',
            'NOD', 'VHR', 'CDN', 'ZSV', 'KCH', 'ODK', 'RSZ', 'HVR'
        ]

        self.image_paths = self.convert_pdf_to_images("contrast.pdf")

        self.layout = MDBoxLayout(orientation='vertical', padding=20, spacing=10)
        self.scroll = ScrollView()
        self.scroll.add_widget(self.layout)
        self.add_widget(self.scroll)

        back_button = MDIconButton(icon="arrow-left", pos_hint={"center_x": 0.1, "center_y": 0.9})
        back_button.bind(on_release=self.go_back)
        self.layout.add_widget(back_button)

        self.layout.add_widget(MDLabel(text="Left Eye Contrast Sensitivity Test", halign="center", font_style="H6"))

        self.preview_label = MDLabel(text="", halign="center", theme_text_color="Secondary")
        self.layout.add_widget(self.preview_label)

        self.image_widget = KivyImage(size_hint_y=1.5, allow_stretch=True, keep_ratio=True)
        self.layout.add_widget(self.image_widget)

        self.input_field = MDTextField(hint_text="Enter the letters visible to you", mode="rectangle")
        self.layout.add_widget(self.input_field)

        self.submit_button = MDRaisedButton(text="Submit", on_release=self.check_answer)
        self.layout.add_widget(self.submit_button)

        self.update_question()

    def on_enter(self):
        self.show_instructions()

    def show_instructions(self):
        instruction_text = (
            "Instructions for the Left Eye Color Vision Test:\n\n"
            "1. Please cover your right eye.\n"
            "2. Focus on the provided images.\n"
            "3. Enter the letters visible to you on the screen.\n"
            "4. If no letter is visible, leave the textbox blank."
        )
        self.dialog = MDDialog(
            title="Instructions: Attend the right eye test before attending this test",
            text=instruction_text,
            buttons=[MDTextButton(text="OK", on_release=self.close_dialog)],
        )
        self.dialog.open()

    def close_dialog(self, *args):
        self.dialog.dismiss()

    def convert_pdf_to_images(self, pdf_path, output_folder="contrast_images"):
        os.makedirs(output_folder, exist_ok=True)
        doc = fitz.open(pdf_path)
        image_paths = []

        for i, page in enumerate(doc):
            pix = page.get_pixmap()
            img_path = os.path.join(output_folder, f"page_{i + 1}.png")
            pix.save(img_path)
            image_paths.append(img_path)

        return image_paths

    def update_question(self):
        if self.current_index < len(self.image_paths) and self.current_index < len(self.question_points):
            self.image_widget.source = self.image_paths[self.current_index]
            self.input_field.text = ""
            self.preview_label.text = (
                f"Question {self.current_index + 1} of {len(self.correct_answers)}\n"
                f"points: {self.question_points[self.current_index]}"
            )
        else:
            self.end_quiz()

    def check_answer(self, instance):
        user_input = self.input_field.text.strip().upper()
        user_input = re.sub(r'[^A-Z]', '', user_input)

        correct_answer = self.correct_answers[self.current_index].upper()
        correct_letters_sorted = sorted(correct_answer)
        user_letters_sorted = sorted(user_input)

        if user_letters_sorted == correct_letters_sorted:
            self.score += self.question_points[self.current_index]
            self.level = self.question_points[self.current_index]
            self.score = round(self.score, 2)

        self.user_answers.append(user_input)
        self.current_index += 1
        self.update_question()

    def go_back(self, instance):
        self.manager.current = 'contrast_sensitivity_test'

    def finish_and_go_back(self, *args):
        self.dialog.dismiss()
        self.manager.current = 'contrast_sensitivity_test'

    def end_quiz(self):
        app = MDApp.get_running_app()
        app.left_eye_score = self.score

        if self.score > 11.7:
            remark = "excellent"
            result_text = (
                f"You scored {self.score} out of 18\n"
                "Great news! Your contrast sensitivity is within the normal range. "
                "Your eyes are doing a great job recognizing differences between light and dark, "
                "even in dim or challenging lighting. Keep up your regular eye checkups!"
            )
        elif self.score > 8.25:
            remark = "good"
            result_text = (
                f"You scored {self.score} out of 18\n"
                "You're doing well, with a slight change in contrast sensitivity. "
                "You might sometimes notice a bit of difficulty seeing things in low light "
                "or when shades are similar — like reading pale text or spotting steps. "
                "A routine eye checkup can help you stay on track."
            )
        else:
            remark = "requires attention"
            result_text = (
                f"You scored {self.score} out of 18\n"
                "We noticed a significant drop in your contrast sensitivity. "
                "You may find it harder to see clearly in dim lighting or when there’s glare. "
                "This can affect night driving, reading, or recognizing faces. "
                "We recommend visiting your eye care professional for support."
            )

        try:
            global collection
            collection.update_one(
                {"email": app.email},
                {"$set": {
                    "Contrast_sensitivity_results.left_eye_score": self.score,
                    "Contrast_sensitivity_results.left_eye_remark": remark,
                    "Contrast_sensitivity_results.left_eye_level": self.level
                }},
                upsert=True
            )
        except NameError:
            print("Warning: MongoDB collection object 'collection' is not defined.")

        self.dialog = MDDialog(
            title="Test Complete.",
            text=result_text
        )
        self.dialog.open()
        self.go_back_no_args()

    def go_back_no_args(self):
        self.manager.current = 'contrast_sensitivity_test'

class RightEyeTestScreenContrast(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.level = None
        self.score = 0
        self.current_index = 0
        self.user_answers = []

        self.correct_answers = ['VRS', 'KDR', 'NHC', 'SOK', 'SCN', 'OZV', 'CNH', 'ZOK', 'NOD',
                                'VHR', 'CDN', 'ZSV', 'KCH', 'ODK', 'RSZ', 'HVR']

        # Define the points early, before using in update_question
        self.question_points = [round(0.15 * i, 2) for i in range(len(self.correct_answers))]

        self.image_paths = self.convert_pdf_to_images("contrast.pdf")

        self.layout = MDBoxLayout(orientation='vertical', padding=20, spacing=10)
        self.scroll = ScrollView()
        self.scroll.add_widget(self.layout)
        self.add_widget(self.scroll)

        # Back button
        back_button = MDIconButton(icon="arrow-left", pos_hint={"center_x": 0.1, "center_y": 0.9})
        back_button.bind(on_release=self.go_back)
        self.layout.add_widget(back_button)

        self.layout.add_widget(MDLabel(text="Right Eye Contrast Sensitivity Test", halign="center", font_style="H6"))

        self.preview_label = MDLabel(text="", halign="center", theme_text_color="Secondary")
        self.layout.add_widget(self.preview_label)

        self.image_widget = KivyImage(size_hint_y=1.5, allow_stretch=True, keep_ratio=True)
        self.layout.add_widget(self.image_widget)

        self.input_field = MDTextField(hint_text="Enter the letters visible to you", mode="rectangle")
        self.layout.add_widget(self.input_field)

        self.submit_button = MDRaisedButton(text="Submit", on_release=self.check_answer)
        self.layout.add_widget(self.submit_button)

        self.update_question()

    def on_enter(self):
        self.show_instructions()

    def show_instructions(self):
        instruction_text = (
            "Instructions for the Right Eye Contrast Sensitivity Test:\n\n"
            "1. Please cover your left eye.\n"
            "2. Focus on the provided images.\n"
            "3. Enter the letters visible to you on the screen.\n"
            "4. If no letter is visible, leave the textbox blank."
        )
        self.dialog = MDDialog(
            title="Instructions",
            text=instruction_text,
            buttons=[MDTextButton(text="OK", on_release=self.close_dialog)],
        )
        self.dialog.open()

    def close_dialog(self, *args):
        self.dialog.dismiss()

    def convert_pdf_to_images(self, pdf_path, output_folder="contrast_images"):
        os.makedirs(output_folder, exist_ok=True)
        doc = fitz.open(pdf_path)
        image_paths = []

        for i, page in enumerate(doc):
            pix = page.get_pixmap()
            img_path = os.path.join(output_folder, f"page_{i + 1}.png")
            pix.save(img_path)
            image_paths.append(img_path)

        return image_paths

    def update_question(self):
        if self.current_index < len(self.image_paths):
            self.image_widget.source = self.image_paths[self.current_index]
            self.input_field.text = ""
            self.preview_label.text = (
                f"Question {self.current_index + 1} of {len(self.correct_answers)}\n"
                f"Points: {self.question_points[self.current_index]}"
            )
        else:
            self.end_quiz()

    def check_answer(self, instance):
        user_input = self.input_field.text.strip().upper()
        user_input = re.sub(r'[^A-Z]', '', user_input)

        correct_answer = self.correct_answers[self.current_index].upper()
        if sorted(user_input) == sorted(correct_answer):
            self.score += self.question_points[self.current_index]
            self.level = self.question_points[self.current_index]
            self.score = round(self.score, 2)

        self.user_answers.append(user_input)
        self.current_index += 1
        self.update_question()

    def go_back(self, instance):
        self.manager.current = 'contrast_sensitivity_test'

    def finish_and_go_back(self, *args):
        self.dialog.dismiss()
        self.manager.current = 'contrast_sensitivity_test'

    def end_quiz(self):
        app = MDApp.get_running_app()
        app.right_eye_contrast_score = self.score

        if self.score > 11.7:
            remark = "excellent"
            result_text = (
                f"You scored {self.score} out of 18\n"
                "Great news! Your contrast sensitivity is within the normal range. "
                "Your eyes are doing a great job recognizing differences between light and dark, even in dim or challenging lighting. "
                "Keep up your regular eye checkups to maintain healthy vision!"
            )
        elif self.score > 8.25:
            remark = "good"
            result_text = (
                f"You scored {self.score} out of 18\n"
                "You're doing well, with a slight change in contrast sensitivity. You might sometimes notice a bit of difficulty seeing things in low light or when shades are similar — "
                "like reading pale text or spotting steps. It’s nothing to worry about, but a routine eye checkup can help you stay on track."
            )
        else:
            remark = "requires attention"
            result_text = (
                f"You scored {self.score} out of 18\n"
                "We noticed a significant drop in your contrast sensitivity, but don’t worry — you're not alone. "
                "You may find it harder to see clearly in dim lighting or when there’s glare. This can affect night driving, reading, or recognizing faces. "
                "We recommend visiting your eye care professional to explore ways to support and improve your vision."
            )

        # Try saving to MongoDB
        try:
            global collection
            collection.update_one(
                {"email": app.email},
                {"$set": {
                    "Contrast_sensitivity_results.right_eye_score": self.score,
                    "Contrast_sensitivity_results.right_eye_remark": remark,
                    "Contrast_sensitivity_results.right_eye_level": self.level
                }},
                upsert=True
            )
        except NameError:
            print("Warning: MongoDB collection object 'collection' is not defined.")

        self.dialog = MDDialog(
            title="Test Complete - You can now proceed to take the left eye test",
            text=result_text
        )
        self.dialog.open()

        # Delay screen transition until after user dismisses dialog
        self.dialog.bind(on_dismiss=self.go_back_no_args)

    def go_back_no_args(self, *args):
        self.manager.current = 'contrast_sensitivity_test'




        

class AmslerGridTestScreen(Screen):
    def __init__(self, test_title="Amsler Grid Test", instructions="Attend the right eye test and then attend the left eye test", **kwargs):
        super().__init__(**kwargs)

        app = MDApp.get_running_app()
        theme_cls = app.theme_cls
        is_light = theme_cls.theme_style == "Light"

        # Root layout with translucent blue background (to match ColorVisionTestScreen)
        self.root_layout = MDBoxLayout(
            orientation='vertical',
            padding=[20, 40, 20, 30],
            spacing=30,
            size_hint=(1, 1)
        )

        with self.root_layout.canvas.before:
            Color(0, 0.486, 1, 0.24)
            self.rect = Rectangle(pos=self.root_layout.pos, size=self.root_layout.size)
        self.root_layout.bind(pos=self._update_rect, size=self._update_rect)

        # Top bar with back button
        top_bar = MDBoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=dp(56),
            md_bg_color=[0, 0, 0, 0]
        )
        back_button = MDIconButton(
            icon="arrow-left",
            size_hint=(None, None),
            icon_size="20dp",
            theme_icon_color="Custom",
            icon_color=[0, 0, 0, 1] if is_light else [1, 1, 1, 1],
            md_bg_color=[0.9, 0.9, 0.9, 0.15] if is_light else [0.3, 0.3, 0.3, 0.15]
        )
        back_button.bind(on_release=self.go_back)
        top_bar.add_widget(back_button)
        self.root_layout.add_widget(top_bar)

        # Title labels
        self.root_layout.add_widget(MDLabel(
            text=test_title,
            halign="center",
            font_style="H5",
            size_hint_y=None,
            height=dp(60),
            theme_text_color="Primary",
            font_name="Roboto"
        ))
        self.root_layout.add_widget(MDLabel(
            text=instructions,
            halign="center",
            font_style="Body2",
            size_hint_y=None,
            height=dp(60),
            theme_text_color="Primary",
            font_name="Roboto"
        ))

        # Card-style layout for buttons
        button_card = MDCard(
            orientation='vertical',
            spacing=20,
            padding=dp(15),
            size_hint=(0.85, None),
            height=dp(150),
            pos_hint={'center_x': 0.5},
            md_bg_color=[1, 1, 1, 1] if is_light else [0.25, 0.25, 0.25, 1],
            radius=[12, 12, 12, 12],
            elevation=2
        )

        # Right Eye Test Button
        right_eye_btn = MDRaisedButton(
            text="Right Eye Test",
            size_hint=(1, None),
            height=dp(48),
            md_bg_color=theme_cls.primary_color,
            text_color=[1, 1, 1, 1],
            font_size="15sp",
            font_name="Roboto",
            line_color=[0.7, 0.7, 0.7, 0.25] if is_light else [0.5, 0.5, 0.5, 0.25]
        )
        right_eye_btn.bind(on_release=lambda x: self.start_test('right_eye_test_ag'))
        button_card.add_widget(right_eye_btn)

        # Left Eye Test Button
        left_eye_btn = MDRaisedButton(
            text="Left Eye Test",
            size_hint=(1, None),
            height=dp(48),
            md_bg_color=theme_cls.primary_color,
            text_color=[1, 1, 1, 1],
            font_size="15sp",
            font_name="Roboto",
            line_color=[0.7, 0.7, 0.7, 0.25] if is_light else [0.5, 0.5, 0.5, 0.25]
        )
        left_eye_btn.bind(on_release=lambda x: self.start_test('left_eye_test_ag'))
        button_card.add_widget(left_eye_btn)

        self.root_layout.add_widget(button_card)
        self.add_widget(self.root_layout)

    def _update_rect(self, *args):
        self.rect.pos = self.root_layout.pos
        self.rect.size = self.root_layout.size

    def go_back(self, instance):
        self.manager.current = 'main'

    def start_test(self, test_screen_name):
        self.manager.current = test_screen_name



class LeftEyeTestScreenAG(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.dialog = None
        self.points = 0
        self.result_dialog = None
        self.answers = {
            "q1": None,
            "q2": None,
            "q3": [],
            "q4": None,
            "q5": None,
            "q6": None
        }
        self._build_ui()

    def _build_ui(self):
        scroll_view = ScrollView()
        layout = MDBoxLayout(orientation='vertical', padding=20, spacing=20, size_hint_y=None)
        layout.bind(minimum_height=layout.setter('height'))

        # Top bar
        top_bar = MDBoxLayout(orientation='horizontal', size_hint_y=None, height=50, padding=[10, 10])
        back_button = MDIconButton(icon="arrow-left")
        back_button.bind(on_release=self.go_back)
        title_label = MDLabel(text="Left Eye Test", halign="center", font_style="H6")
        top_bar.add_widget(back_button)
        top_bar.add_widget(title_label)
        top_bar.add_widget(MDBoxLayout(size_hint_x=None, width=48))  # Spacer
        layout.add_widget(top_bar)
        layout.add_widget(MDBoxLayout(size_hint_y=None, height=20))  # Spacer

        # Image
        image_box = MDBoxLayout(orientation='vertical', size_hint=(1, None), height=390)
        image_box.add_widget(Widget())
        self.ag_image = KivyImage(
            source="A_G_image.png",
            allow_stretch=True,
            keep_ratio=True,
            size_hint=(1, None),
            height=Window.width  # Assume 1:1 aspect ratio initially
        )

        # Dynamically update image height based on width (for responsiveness)
        def update_height(instance, value):
            self.ag_image.height = value  # Maintain square aspect ratio
        Window.bind(width=update_height)

        layout.add_widget(self.ag_image) 
        image_box.add_widget(Widget())
        layout.add_widget(image_box)

        layout.add_widget(Widget(size_hint_y=None, height=30))  # Spacer before questions

        # Add yes/no question with radio-style checkboxes
        def add_radio_question(text, options, group_name, answer_key):
            layout.add_widget(MDLabel(text=text, halign="left", theme_text_color="Primary", size_hint_y=None, height=40))
            for opt in options:
                opt_layout = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=40, spacing=10)
                checkbox = MDCheckbox(group=group_name, size_hint=(None, None), size=(30, 30))

                def on_checkbox_active(checkbox_instance, value, option=opt):
                    if value:
                        self.answers[answer_key] = 1 if option == "Yes" else 0

                checkbox.bind(active=on_checkbox_active)
                opt_layout.add_widget(checkbox)
                opt_layout.add_widget(MDLabel(text=opt, valign="middle"))
                layout.add_widget(opt_layout)
            layout.add_widget(Widget(size_hint_y=None, height=10))

        # Add custom checkbox logic for Q3
        def add_custom_checkbox_question(text, options, answer_key):
            layout.add_widget(MDLabel(text=text, halign="left", theme_text_color="Primary", size_hint_y=None, height=40))
            self.q3_checkboxes = []

            for idx, opt in enumerate(options):
                opt_layout = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=40, spacing=10)
                checkbox = MDCheckbox(size_hint=(None, None), size=(30, 30))
                opt_layout.add_widget(checkbox)
                opt_layout.add_widget(MDLabel(text=opt, valign="middle"))
                layout.add_widget(opt_layout)

                self.q3_checkboxes.append((checkbox, idx + 1))

                def on_checkbox_active(checkbox_instance, value, i=idx):
                    if value:
                        if i == 0:  # "Straight" selected
                            for j in range(1, 4):
                                self.q3_checkboxes[j][0].active = False
                        else:
                            self.q3_checkboxes[0][0].active = False

                    # Update answers list
                    selected = [val for (cb, val) in self.q3_checkboxes if cb.active]
                    self.answers[answer_key] = selected

                checkbox.bind(active=on_checkbox_active)

            layout.add_widget(Widget(size_hint_y=None, height=10))

        # Questions
        add_radio_question("1. Can you see the center dot clearly?", ["Yes", "No"], "q1_group", "q1")
        add_radio_question("2. While focusing on the center dot, can you see all four corners and the edges of the grid?", ["Yes", "No"], "q2_group", "q2")
        add_custom_checkbox_question("3. Are all the lines straight, or do any appear wavy, curved, or distorted?", ["Straight", "Wavy", "Curved", "Distorted"], "q3")
        add_radio_question("4. Is there any area where the lines are missing or appear blurry?", ["Yes", "No"], "q4_group", "q4")
        add_radio_question("5. Does any part of the grid look darker or faded compared to the rest?", ["Yes", "No"], "q5_group", "q5")
        add_radio_question("6. Is the size or shape of any area on the grid different?", ["Yes", "No"], "q6_group", "q6")

        # Submit Button
        submit_button = MDRaisedButton(text="Submit Answers", on_release=self.submit_answers, size_hint_y=None, height=50)
        layout.add_widget(submit_button)

        layout.add_widget(Widget(size_hint_y=None, height=50))
        scroll_view.add_widget(layout)
        self.add_widget(scroll_view)

    def on_enter(self):
        if not self.dialog:
            self.dialog = MDDialog(
                title="Read Instructions carefully for precise test results, Ensure that you have completed the right eye test first",
                text=(
                    "1. Cover your right eye and focus on the center of the grid.\n"
                    "2. Place your screen at arm's length.\n"
                    "3. Look into the black dot at the center only.\n"
                    "4. Answer the questions that follow."
                ),
                buttons=[MDRaisedButton(text="OK", on_release=lambda x: self.dialog.dismiss())]
            )
        self.dialog.open()

    def go_back(self, instance):
        print("Collected Answers:", self.answers)  # Optional: Debugging
        self.manager.current = 'amsler_grid_test'

    def submit_answers(self, instance):
        print("Submitting Left Eye Answers:", self.answers)
        if self.answers['q1'] == 1:
            self.points += 1
        if self.answers['q2'] == 1:
            self.points += 1
        if 1 in self.answers['q3']:
            self.points += 1
        if self.answers['q4'] == 0:
            self.points += 1
        if self.answers['q5'] == 0:
            self.points+=1
        if self.answers['q6'] == 0:
            self.points += 1

        app = MDApp.get_running_app()

        # Save score to MongoDB

        if self.points == 6:
            remark = "excellent"
            result = "Your test looks good. All the lines are straight and clear, which means the central vision is healthy. That’s a great sign."
        else:
            remark = "requires attention"
            result = "Some lines appear bent, blurry, or missing. This might mean there's a change in the central vision. It doesn't always mean something serious, but it's important to get it checked by an eye doctor soon. Early care can protect your vision."

        global collection
        collection.update_one(
                    {"email": app.email},
                    {"$set": {
                        "amsler_grid_test_results.left_eye_score": self.points,
                        "amsler_grid_test_results.left_eye_remark": remark
                    }},
                    upsert=True # Creates the document if it doesn't exist
                )
        if not self.result_dialog:
            self.result_dialog = MDDialog(
                title="TEST RESULTS",
                text=(
                    f"1. You scored {self.points}/{6} .\n"
                    f"2. {result}.\n"
                ),
                buttons=[MDRaisedButton(text="OK", on_release=lambda x: self.dialog.dismiss())]
            )
        self.manager.current = 'amsler_grid_test'
        self.result_dialog.open()
        

        
            
        



class RightEyeTestScreenAG(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.dialog = None
        self.points = 0
        self.result_dialog = None
        self.answers = {
            "q1": None,
            "q2": None,
            "q3": [],
            "q4": None,
            "q5": None,
            "q6": None
        }
        self._build_ui()
    
    def _build_ui(self):
        scroll_view = ScrollView()
        layout = MDBoxLayout(orientation='vertical', padding=20, spacing=20, size_hint_y=None)
        layout.bind(minimum_height=layout.setter('height'))

        # Top bar
        top_bar = MDBoxLayout(orientation='horizontal', size_hint_y=None, height=50, padding=[10, 10])
        back_button = MDIconButton(icon="arrow-left")
        back_button.bind(on_release=self.go_back)
        title_label = MDLabel(text="Right Eye Test", halign="center", font_style="H6")
        top_bar.add_widget(back_button)
        top_bar.add_widget(title_label)
        top_bar.add_widget(MDBoxLayout(size_hint_x=None, width=48))  # Spacer
        layout.add_widget(top_bar)
        layout.add_widget(MDBoxLayout(size_hint_y=None, height=20))  # Spacer

        # Image
        image_box = MDBoxLayout(orientation='vertical', size_hint=(1, None), height=390)
        image_box.add_widget(Widget())
        self.ag_image = KivyImage(
            source="A_G_image.png",
            allow_stretch=True,
            keep_ratio=True,
            size_hint=(1, None),
            height=Window.width  # Assume 1:1 aspect ratio initially
        )

        # Dynamically update image height based on width (for responsiveness)
        def update_height(instance, value):
            self.ag_image.height = value  # Maintain square aspect ratio
        Window.bind(width=update_height)

        layout.add_widget(self.ag_image)
        image_box.add_widget(Widget())
        layout.add_widget(image_box)

        layout.add_widget(Widget(size_hint_y=None, height=30))  # Spacer before questions

        # Add yes/no question with radio-style checkboxes
        def add_radio_question(text, options, group_name, answer_key):
            layout.add_widget(MDLabel(text=text, halign="left", theme_text_color="Primary", size_hint_y=None, height=40))
            for opt in options:
                opt_layout = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=40, spacing=10)
                checkbox = MDCheckbox(group=group_name, size_hint=(None, None), size=(30, 30))

                def on_checkbox_active(checkbox_instance, value, option=opt):
                    if value:
                        self.answers[answer_key] = 1 if option == "Yes" else 0

                checkbox.bind(active=on_checkbox_active)
                opt_layout.add_widget(checkbox)
                opt_layout.add_widget(MDLabel(text=opt, valign="middle"))
                layout.add_widget(opt_layout)
                layout.add_widget(Widget(size_hint_y=None, height=10))

        # Add custom checkbox logic for Q3
        def add_custom_checkbox_question(text, options, answer_key):
            layout.add_widget(MDLabel(text=text, halign="left", theme_text_color="Primary", size_hint_y=None, height=40))
            self.q3_checkboxes = []

            for idx, opt in enumerate(options):
                opt_layout = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=40, spacing=10)
                checkbox = MDCheckbox(size_hint=(None, None), size=(30, 30))
                opt_layout.add_widget(checkbox)
                opt_layout.add_widget(MDLabel(text=opt, valign="middle"))
                layout.add_widget(opt_layout)

                self.q3_checkboxes.append((checkbox, idx + 1))

                def on_checkbox_active(checkbox_instance, value, i=idx):
                    if value:
                        if i == 0:  # "Straight" selected
                            for j in range(1, 4):
                                self.q3_checkboxes[j][0].active = False
                        else:
                            self.q3_checkboxes[0][0].active = False

                    # Update answers list
                    selected = [val for (cb, val) in self.q3_checkboxes if cb.active]
                    self.answers[answer_key] = selected

                checkbox.bind(active=on_checkbox_active)

            layout.add_widget(Widget(size_hint_y=None, height=10))

        # Questions
        add_radio_question("1. Can you see the center dot clearly?", ["Yes", "No"], "q1_group_right", "q1")
        add_radio_question("2. While focusing on the center dot, can you see all four corners and the edges of the grid?", ["Yes", "No"], "q2_group_right", "q2")
        add_custom_checkbox_question("3. Are all the lines straight, or do any appear wavy, curved, or distorted?", ["Straight", "Wavy", "Curved", "Distorted"], "q3")
        add_radio_question("4. Is there any area where the lines are missing or appear blurry?", ["Yes", "No"], "q4_group_right", "q4")
        add_radio_question("5. Does any part of the grid look darker or faded compared to the rest?", ["Yes", "No"], "q5_group_right", "q5")
        add_radio_question("6. Is the size or shape of any area on the grid different?", ["Yes", "No"], "q6_group_right", "q6")

        # Submit Button
        submit_button = MDRaisedButton(text="Submit Answers", on_release=self.submit_answers, size_hint_y=None, height=50)
        layout.add_widget(submit_button)

        layout.add_widget(Widget(size_hint_y=None, height=50))
        scroll_view.add_widget(layout)
        self.add_widget(scroll_view)
        self.layout = layout # To access in submit_answers
        self.scroll_view = scroll_view # To access if needed

    def on_enter(self):
        if not self.dialog:
            self.dialog = MDDialog(
                title="Read Instructions carefully for precise test results",
                text=(
                    "1. Cover your left eye and focus on the center of the grid.\n"
                    "2. Place your screen at arm's length.\n"
                    "3. Look into the black dot at the center only.\n"
                    "4. Answer the questions that follow."
                ),
                buttons=[MDRaisedButton(text="OK", on_release=lambda x: self.dialog.dismiss())]
            )
        self.dialog.open()

    def go_back(self, instance):
        print("Collected Answers (Right Eye):", self.answers)  # Optional: Debugging
        self.manager.current = 'amsler_grid_test'

    def submit_answers(self, instance):
        print("Submitting Right Eye Answers:", self.answers)
        self.points = 0
        if self.answers['q1'] == 1:
            self.points += 1
        if self.answers['q2'] == 1:
            self.points += 1
        if 1 in self.answers['q3']:
            self.points += 1
        if self.answers['q4'] == 0:
            self.points += 1
        if self.answers['q5'] == 0:
            self.points += 1
        if self.answers['q6'] == 0:
            self.points += 1

        app = MDApp.get_running_app()

        # Save score to MongoDB


        if self.points == 6:
            remark = "excellent"
            result = "Your test looks good. All the lines are straight and clear, which means the central vision is healthy. That’s a great sign."
        else:
            remark = "requires attention"
            result = "Some lines appear bent, blurry, or missing. This might mean there's a change in the central vision. It doesn't always mean something serious, but it's important to get it checked by an eye doctor soon. Early care can protect your vision."
        global collection
        collection.update_one(
                    {"email": app.email},
                    {"$set": {
                        "amsler_grid_test_results.right_eye_score": self.points,
                        "amsler_grid_test_results.right_eye_remark": remark
                    }},
                    upsert=True # Creates the document if it doesn't exist
                )

        if not self.result_dialog:
            self.result_dialog = MDDialog(
                title="TEST RESULTS",
                text=(
                    f"1. You scored {self.points}/{6} .\n"
                    f"2. {result}.\n"
                    "3. The Amsler Grid test for the right eye is complete, You may now proceed to take the left eye test."
                ),
                buttons=[MDRaisedButton(text="OK", on_release=lambda x: self.result_dialog.dismiss())]
            )
        self.result_dialog.open()
        self.manager.current = 'left_eye_test_ag'


class StereopsisTestScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.q1_answers = {}  # store references to q1 checkboxes
        self.q2_answers = {}  # store references to q2 checkboxes

        layout = MDBoxLayout(orientation='vertical', padding=10, spacing=15)

        # Back button
        back_button = MDIconButton(
            icon="arrow-left",
            pos_hint={"center_x": 0.1, "center_y": 0.9},
            icon_size="20dp"
        )
        back_button.bind(on_release=self.go_back)
        layout.add_widget(back_button)

        # Title
        layout.add_widget(MDLabel(
            text="Stereopsis Test",
            halign="center",
            font_style="H4"
        ))

        # Display test image
        layout.add_widget(KivyImage(
            source="lang.jpg",
            size_hint=(1, 1),
            allow_stretch=True,
            keep_ratio=True
        ))

        # First Question
        q1_label = MDLabel(
            text="How many figures is the patient able to identify?",
            halign="left",
            font_style="H6",
            size_hint_y=None,
            height=40
        )
        layout.add_widget(q1_label)

        q1_options = MDBoxLayout(orientation="horizontal", spacing=20, size_hint_y=None, height=40)
        for option in ["1", "2", "3", "4+"]:
            cb = MDCheckbox(group="q1")
            self.q1_answers[option] = cb
            q1_options.add_widget(cb)
            q1_options.add_widget(MDLabel(text=option))
        layout.add_widget(q1_options)

        # Second Question
        q2_label = MDLabel(
            text="Are the images clearly identifiable by the patient?",
            halign="left",
            font_style="H6",
            size_hint_y=None,
            height=40
        )
        layout.add_widget(q2_label)

        q2_options = MDBoxLayout(orientation="horizontal", spacing=20, size_hint_y=None, height=40)
        for option in ["Yes", "No"]:
            cb = MDCheckbox(group="q2")
            self.q2_answers[option] = cb
            q2_options.add_widget(cb)
            q2_options.add_widget(MDLabel(text=option))
        layout.add_widget(q2_options)

        # Submit Button
        submit_button = MDRaisedButton(
            text="Submit",
            pos_hint={"center_x": 0.5},
            size_hint=(None, None),
            size=("120dp", "48dp")
        )
        submit_button.bind(on_release=self.calculate_score)
        layout.add_widget(submit_button)

        # Result Label
        self.result_label = MDLabel(
            text="",
            halign="center",
            font_style="H6",
            theme_text_color="Secondary"
        )
        layout.add_widget(self.result_label)

        self.add_widget(layout)

    def calculate_score(self, instance):
        score = 0

        # Scoring for Q1
        if self.q1_answers["1"].active:
            score = 1
        elif self.q1_answers["2"].active:
            score = 2
        elif self.q1_answers["3"].active:
            score = 3
        elif self.q1_answers["4+"].active:
            score = 0

        # If Q2 is "No", reset score
        if self.q2_answers["No"].active:
            score = 0

        self.result_label.text = f"Result: {score} points"
        if score==3:
            remark = "excellent"
        else:
            remark = "action needed"
        app = MDApp.get_running_app()
        if hasattr(app, 'email') and collection is not None:
            try:
                collection.update_one(
                    {"email": app.email},
                    {"$set": {
                        "Stereopsis_results.both_eye_score": score,
                        "Stereopsis_results.both_eye_remark": remark
                    }},
                    upsert=True
                )
                print("Database updated successfully.")
            except Exception as e:
                print(f"Error updating database: {e}")


    def go_back(self, instance):
        self.manager.current = 'main'



class NearVisionTestScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.selected_language = None  # To store the chosen language

        app = MDApp.get_running_app()
        theme_cls = app.theme_cls
        is_light = theme_cls.theme_style == "Light"

        self.root_layout = MDBoxLayout(
            orientation='vertical',
            padding=[20, 40, 20, 30],
            spacing=30,
            size_hint=(1, 1)
        )

        # Background color with translucent blue
        with self.root_layout.canvas.before:
            Color(0, 0.486, 1, 0.24)
            self.rect = Rectangle(pos=self.root_layout.pos, size=self.root_layout.size)
        self.root_layout.bind(pos=self._update_rect, size=self._update_rect)

        # Top bar with back button
        top_bar = MDBoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=dp(56),
            md_bg_color=[0, 0, 0, 0]
        )
        back_button = MDIconButton(
            icon="arrow-left",
            size_hint=(None, None),
            icon_size="32dp",
            theme_icon_color="Custom",
            icon_color=[0, 0, 0, 1] if is_light else [1, 1, 1, 1],
            md_bg_color=[0.9, 0.9, 0.9, 0.15] if is_light else [0.3, 0.3, 0.3, 0.15]
        )
        back_button.bind(on_release=self.go_back)
        top_bar.add_widget(back_button)
        self.root_layout.add_widget(top_bar)

        # Title
        self.root_layout.add_widget(MDLabel(
            text="Near Vision Test",
            halign="center",
            font_style="H5",
            size_hint_y=None,
            height=dp(60),
            theme_text_color="Primary",
            font_name="Roboto"
        ))
        # This label's text will be updated dynamically
        self.instruction_label = MDLabel(
            text="Start by selecting a language.",
            halign="center",
            font_style="Body2",
            size_hint_y=None,
            height=dp(60),
            theme_text_color="Primary",
            font_name="Roboto"
        )
        self.root_layout.add_widget(self.instruction_label)


        # Card for buttons
        self.card = MDCard(
            orientation='vertical',
            padding=dp(15),
            spacing=dp(20),
            size_hint=(0.85, None),
            height=dp(150),
            pos_hint={'center_x': 0.5},
            md_bg_color=[1, 1, 1, 1] if is_light else [0.25, 0.25, 0.25, 1],
            radius=[12, 12, 12, 12],
            elevation=4
        )
        self.root_layout.add_widget(self.card)

        # Language selection button
        self.language_button = MDRaisedButton(
            text="Select Language",
            size_hint=(1, None),
            height=dp(48),
            md_bg_color=theme_cls.primary_color,
            text_color=[1, 1, 1, 1],
            font_size="15sp",
            font_name="Roboto",
        )
        self.language_button.bind(on_release=self.show_language_menu)
        self.card.add_widget(self.language_button)

        self.add_widget(self.root_layout)

    def _update_rect(self, *args):
        self.rect.pos = self.root_layout.pos
        self.rect.size = self.root_layout.size

    def go_back(self, instance):
        self.manager.current = 'main'

    def show_language_menu(self, instance):
        menu_items = [
            {
                "viewclass": "OneLineListItem",
                "text": "English",
                "on_release": lambda x="English": self.set_language(x),
            },
            {
                "viewclass": "OneLineListItem",
                "text": "Tamil",
                "on_release": lambda x="Tamil": self.set_language(x),
            },
            {
                "viewclass": "OneLineListItem",
                "text": "Telugu",
                "on_release": lambda x="Telugu": self.set_language(x),
            },
            {
                "viewclass": "OneLineListItem",
                "text": "Hindi",
                "on_release": lambda x="Hindi": self.set_language(x),
            },
        ]
        self.menu = MDDropdownMenu(
            caller=self.language_button,
            items=menu_items,
            width_mult=4,
        )
        self.menu.open()

    def set_language(self, language):
        self.selected_language = language
        self.menu.dismiss()
        self.display_test_buttons()

    def display_test_buttons(self):
        # Clear existing buttons in the card, keeping only the language button
        self.card.clear_widgets()
        self.card.add_widget(self.language_button)

        app = MDApp.get_running_app()
        theme_cls = app.theme_cls

        # Add "Right Eye Test" button
        right_eye_button = MDRaisedButton(
            text="Right Eye Test",
            size_hint=(1, None),
            height=dp(48),
            md_bg_color=theme_cls.primary_color,
            text_color=[1, 1, 1, 1],
            font_size="15sp",
            font_name="Roboto",
        )
        right_eye_button.bind(on_release=lambda x: self.start_test('right_eye_test_nv'))
        self.card.add_widget(right_eye_button)

        # Add "Left Eye Test" button
        left_eye_button = MDRaisedButton(
            text="Left Eye Test",
            size_hint=(1, None),
            height=dp(48),
            md_bg_color=theme_cls.primary_color,
            text_color=[1, 1, 1, 1],
            font_size="15sp",
            font_name="Roboto",
        )
        left_eye_button.bind(on_release=lambda x: self.start_test('left_eye_test_nv'))
        self.card.add_widget(left_eye_button)

        # Update the instruction text, now using the stored instruction_label reference
        self.instruction_label.text = f"Proceed with the eye tests in {self.selected_language}."


    def start_test(self, test_screen_name):
        """
        Navigates to the specified test screen and passes the selected language.
        """
        if self.manager:
            # Get the target screen instance
            target_screen = self.manager.get_screen(test_screen_name)
            if target_screen and hasattr(target_screen, 'set_test_language'):
                # Call the setter method on the target screen
                target_screen.set_test_language(self.selected_language)
            
            print(f"Starting {test_screen_name} in {self.selected_language}")
            self.manager.current = test_screen_name
        else:
            print("ScreenManager not available.")


# ✅ Helper to split Tamil syllables
def get_letters(word):
    import tamil.utf8
    return tamil.utf8.get_letters(word)


class NearVisionRight(Screen):
    # Multiplier to artificially increase content height for testing scrolling.
    # Set to 1.0 for normal behavior. Set to >1.0 to force content overflow.
    TEST_OVERFLOW_HEIGHT_MULTIPLIER = 1.0 # This multiplier won't be as directly relevant now for the overall screen height,
                                        # but keep it if you use it elsewhere.

    # Kivy properties for dynamic UI updates
    language = StringProperty(None)
    current_question = 1
    max_questions = 6
    user_answers = []
    score = 0

    # Stores individual characters/syllables typed for non-English languages
    tamil_syllables = []
    hindi_syllables = []
    telugu_syllables = []

    correct_answers = {
        "English": {
            1: "bharat", 2: "anand", 3: "pooja",
            4: "ahmed", 5: "netaji", 6: "nagpur"
        },
        "Tamil": {
            1: "பரத்", 2: "ஆனந்த்", 3: "பூஜா",
            4: "அஹ்மத்", 5: "நிர்மல்", 6: "நாக்பூர்"
        },
        "Hindi": {
            1: "भारत", 2: "आनंद", 3: "पूजा",
            4: "अहमad", 5: "नेताजी", 6: "नागपुर"
        },
        "Telugu": {
            1: "భారత్", 2: "ఆనంద్", 3: "పూజ",
            4: "అహ్మద్", 5: "నేతాజీ", 6: "నాగపూర్"
        }
    }

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # Determine theme style for dynamic icon coloring
        self.app = MDApp.get_running_app()
        self.is_light_theme = self.app.theme_cls.theme_style == "Light"

        self._create_ui()
        self.bind(language=self.on_language_change) # Bind to language property for updates

    def _create_ui(self):
        """Builds the main user interface elements for the screen."""
        # Create a ScrollView that will encompass the entire screen's content
        self.main_scroll_view = ScrollView(
            do_scroll_y=True,
            size_hint=(1, 1)
        )

        self.root_layout = MDBoxLayout(
            orientation='vertical',
            padding=dp(20), # Uniform padding
            spacing=dp(10),
            size_hint_y=None, # Crucial: Let the BoxLayout determine its height based on content
            adaptive_height=True # KivyMD specific: makes size_hint_y=None work well
        )
        # Bind minimum_height so the ScrollView knows the content's total height
        self.root_layout.bind(minimum_height=self.root_layout.setter('height'))


        # Set a white background for the root layout (now inside the scroll view)
        # Note: The background of the scrollable area itself.
        with self.root_layout.canvas.before:
            Color(1, 1, 1, 1) # White background
            self.rect = Rectangle(pos=self.root_layout.pos, size=self.root_layout.size)
        self.root_layout.bind(pos=self._update_rect, size=self._update_rect)


        self.root_layout.add_widget(self._create_title_and_language_labels())
        # Add the main content directly to root_layout, no longer a separate ScrollView
        self.root_layout.add_widget(self._create_word_display_card())
        self.root_layout.add_widget(self._create_english_input_card())
        self.root_layout.add_widget(self._create_non_english_input_card())

        # Add padding at the bottom for the next button to not stick to the edge
        self.root_layout.add_widget(MDBoxLayout(size_hint_y=None, height=dp(20)))

        self.root_layout.add_widget(self._create_next_button())

        # Add the root_layout to the main_scroll_view
        self.main_scroll_view.add_widget(self.root_layout)
        # Add the main_scroll_view to the screen
        self.add_widget(self.main_scroll_view)

    def _update_rect(self, *args):
        """Updates the background rectangle position and size with the root layout."""
        self.rect.pos = self.root_layout.pos
        self.rect.size = self.root_layout.size

    def _create_title_and_language_labels(self):
        """Creates and returns a layout with title and language labels."""
        label_layout = MDBoxLayout(
            orientation='vertical',
            spacing=dp(5), # Reduced spacing for a tighter look
            size_hint_y=None,
            adaptive_height=True # Let height adapt to content
        )
        self.title_label = MDLabel(
            halign="center",
            font_style="H5",
            markup=True, # Enable markup for bold text
            color=(0, 0, 0, 1) # Black text for light theme
        )
        self.language_label = MDLabel(
            halign="center",
            theme_text_color="Secondary", # Subtle secondary color
            font_style="Body1"
        )
        label_layout.add_widget(self.title_label)
        label_layout.add_widget(self.language_label)
        return label_layout

    # Removed _create_scrollable_content as it's no longer needed,
    # the entire screen is now scrollable.

    def _create_word_display_card(self):
        """Creates and returns the card for displaying the word/image."""
        self.word_display_card = MDCard(
            orientation='vertical',
            padding=dp(20),
            spacing=dp(15), # Increased spacing within the card
            size_hint_y=None,
            height=dp(200), # Original height for the card
            elevation=4, # More pronounced shadow
            line_color=self.app.theme_cls.primary_color, # Primary color border
            line_width=1.5, # Thicker border
            md_bg_color=[1, 1, 1, 1], # White background for the card
            radius=[dp(12),] # Rounded corners
        )
        self.image_widget = KivyImage(
            source="",
            size_hint=(None, None),
            size=(dp(300), dp(150)), # Retained original image size
            pos_hint={"center_x": 0.5, "center_y": 0.5}, # Center both ways
            allow_stretch=False,
            keep_ratio=True
        )

        self.word_display_card.add_widget(self.image_widget)
        return self.word_display_card

    def _create_english_input_card(self):
        """Creates and returns the card for English text input."""
        self.english_input_card = MDCard(
            orientation='vertical',
            padding=dp(20),
            spacing=dp(10),
            size_hint_y=None,
            height=dp(110), # Slightly more height
            elevation=4,
            line_color=self.app.theme_cls.primary_color,
            line_width=1.5,
            md_bg_color=[1, 1, 1, 1],
            radius=[dp(12),]
        )
        self.answer_input = MDTextField(
            hint_text="Type what you see...",
            mode="fill", # Modern fill mode for text field
            size_hint_y=None,
            height=dp(60),
            font_size="18sp", # Slightly larger font
        )
        # Set these properties after the main initialization for robustness
        self.answer_input.fill_color = self.app.theme_cls.bg_normal
        self.answer_input.line_color_normal = self.app.theme_cls.primary_color
        self.answer_input.text_color = self.app.theme_cls.text_color # Ensure text color is set by theme

        self.english_input_card.add_widget(self.answer_input)
        return self.english_input_card

    def _create_non_english_input_card(self):
        """Creates and returns the card for non-English keypad input."""
        self.non_english_input_card = MDCard(
            orientation="vertical",
            spacing=dp(20),
            padding = 35,
            size_hint=(1, None),
            adaptive_height=True,
            elevation=4,
            line_color=self.app.theme_cls.primary_color,
            line_width=1.5,
            md_bg_color=[1, 1, 1, 1],
            radius=[dp(12),]
        )
        self.non_english_answer_label = MDLabel(
            text="", halign="center",
            font_name="TeluguFont" if self.language == "Telugu" else "HindiFont" if self.language == "Hindi" else "TamilFont",
            theme_text_color="Custom", text_color=(0, 0, 0, 1), font_size="32sp", # Larger font for answer
            size_hint_y=None, height=dp(60), # More height for display
            markup=True
        )
        self.non_english_input_card.add_widget(self.non_english_answer_label)

        self.letter_grid = MDGridLayout(
            cols=3,
            spacing=dp(5), 
            adaptive_height=True,
            size_hint_y=None,
            row_force_default=False,
            row_default_height=dp(58) # Slightly larger buttons
        )
        self.letter_grid.bind(minimum_height=self.letter_grid.setter('height'))
        self.non_english_input_card.add_widget(self.letter_grid)

        control_buttons = MDBoxLayout(
            size_hint=(1, None),
            height=dp(55), # More height for control buttons
            spacing=dp(15), # Spacing between control buttons
            padding=(0, dp(10), 0, 0) # Top padding
        )
        clear_btn = MDRaisedButton(
            text="Clear",
            size_hint_x=0.5,
            md_bg_color=self.app.theme_cls.accent_color # Accent color for clear
        )
        clear_btn.bind(on_release=self.clear_non_english_input)
        backspace_btn = MDRaisedButton(
            text="⌫",
            size_hint_x=0.5,
            md_bg_color=self.app.theme_cls.error_color # Error color for backspace
        )
        backspace_btn.bind(on_release=self.backspace_non_english_input)
        control_buttons.add_widget(clear_btn)
        control_buttons.add_widget(backspace_btn)
        self.non_english_input_card.add_widget(control_buttons)

        self.non_english_input_card.opacity = 0
        self.non_english_input_card.disabled = True

        return self.non_english_input_card

    def _create_next_button(self):
        """Creates and returns the 'Next' button."""
        self.next_button = MDRaisedButton(
            text="NEXT", # Uppercase text
            font_style="Button",
            pos_hint={"center_x": 0.5},
            size_hint=(0.5, None), # Wider button
            height=dp(52), # Taller button
            md_bg_color=self.app.theme_cls.primary_color, # Primary color for main action
            line_color=(0,0,0,0), # No line
            shadow_radius=dp(8), # More prominent shadow
            shadow_offset=(0, dp(2))
        )
        self.next_button.bind(on_release=self.next_question)
        return self.next_button

    def go_back(self, instance):
        """Navigates back to the near_vision_test screen."""
        self.manager.current = 'near_vision_test'

    def on_language_change(self, instance, value):
        """Called when the language property changes, updates UI accordingly."""
        self.update_answer_label_font()
        # Only setup non-english letters if it's a non-english language
        if value in ["Tamil", "Hindi", "Telugu"]:
            self.setup_non_english_letters()

    def update_answer_label_font(self):
        """Updates the font of the non-English answer label based on the selected language."""
        self.non_english_answer_label.font_name = (
            "TeluguFont" if self.language == "Telugu" else
            "HindiFont" if self.language == "Hindi" else
            "TamilFont"
        )
        self.non_english_answer_label.texture_update()

    def set_test_language(self, language: str):
        """
        Sets the language for the test and reconfigures the UI accordingly.
        Args:
            language (str): The selected language (e.g., "English", "Tamil").
        """
        self.language = language
        self.current_question = 1
        self.user_answers = []
        self.score = 0

        self.tamil_syllables.clear()
        self.hindi_syllables.clear()
        self.telugu_syllables.clear()

        # Show/hide relevant input cards
        if language == "English":
            self.english_input_card.opacity = 1
            self.english_input_card.disabled = False
            self.non_english_input_card.opacity = 0
            self.non_english_input_card.disabled = True
        elif language in ["Tamil", "Hindi", "Telugu"]:
            self.english_input_card.opacity = 0
            self.english_input_card.disabled = True
            self.non_english_input_card.opacity = 1
            self.non_english_input_card.disabled = False
            # Font update and keypad setup are now handled by on_language_change binding
        self.load_question()

    def load_question(self):
        """Loads the current question's image and resets input fields."""
        img_dir = {
            "English": "nv_english",
            "Tamil": "nv_tamil",
            "Hindi": "nv_hindi",
            "Telugu": "nv_telugu"
        }.get(self.language, "nv_english")

        # The problem was likely here - the path needs to start from the root of where Kivy expects assets
        # If 'assets' is a top-level folder in your project, the path should be relative to it.
        # So, it should be f"assets/images/{img_dir}/image_{self.current_question}.png"
        self.image_widget.source = f"{img_dir}/image_{self.current_question}.png"
        self.image_widget.reload()

        self.answer_input.text = ""
        self.clear_non_english_input(None)

        # setup_non_english_letters is now triggered by on_language_change,
        # but calling it here again ensures it reloads for each question
        if self.language in ["Tamil", "Hindi", "Telugu"]:
            self.setup_non_english_letters()

    def setup_non_english_letters(self):
        """Generates and displays buttons for the non-English keypad."""
        self.letter_grid.clear_widgets()
        correct_word = self.correct_answers.get(self.language, {}).get(self.current_question, "")
        correct_syllables = list(correct_word) # Simple character split for now (adjust for complex scripts if needed)

        unique_syllables = list(set(correct_syllables))

        # Define a pool of distractors specific to each language
        # These lists should be comprehensive and ideally based on common characters
        # or phonemes for the respective languages.
        if self.language == "Tamil":
            distractors_pool = list(set([
                "அ", "ஆ", "இ", "ஈ", "உ", "ஊ", "எ", "ஏ", "ஐ", "ஒ", "ஓ", "ஔ", "க", "ங", "ச", "ஞ", "ட", "ண", "த", "ந",
                "ப", "ம", "ய", "ர", "ல", "வ", "ழ", "ற", "ன", "ஸ்ரீ", "க்", "ங்", "ச்", "ஞ்", "ட்", "ண்", "த்", "ந்",
                "ப்", "ம்", "ய்", "ர்", "ல்", "வ்", "ழ்", "ற்", "ன்", "ா", "ி", "ீ", "ு", "ூ", "ெ", "ே", "ை", "ொ", "ோ", "ௌ",
                "கு", "மு", "தி", "வி", "சி", "கெ", "மே", "தூ", "னை", "ஜோ"
            ]) - set(unique_syllables))
        elif self.language == "Hindi":
            distractors_pool = list(set([
                "अ", "आ", "इ", "ई", "उ", "ऊ", "ऋ", "ए", "ऐ", "ओ", "औ", "क", "ख", "ग", "घ", "ङ", "च", "छ", "ज", "झ",
                "ञ", "ट", "ठ", "ड", "ढ", "ण", "त", "थ", "द", "ध", "न", "प", "फ", "ब", "भ", "म", "य", "र", "ल", "व",
                "श", "ष", "स", "ह", "ा", "ि", "ी", "ु", "ू", "ृ", "े", "ै", "ो", "ौ", "ं", "ः", "्", "क़", "ख़", "ग़", "ज़", "फ़", "ड़", "ढ़",
                "कृ", "रु", "लौ", "कि", "मो", "ते", "सू", "प्र", "शृ"
            ]) - set(unique_syllables))
        elif self.language == "Telugu":
            distractors_pool = list(set([
                "అ", "ఆ", "ఇ", "ఈ", "ఉ", "ఊ", "ఋ", "ఎ", "ఏ", "ఐ", "ఒ", "ఓ", "ఔ", "క", "ఖ", "గ", "ఘ", "ఙ", "చ", "ఛ",
                "జ", "ఝ", "ఞ", "ట", "ఠ", "డ", "ఢ", "ణ", "త", "థ", "ద", "ధ", "న", "ప", "ఫ", "బ", "భ", "మ", "య", "ర",
                "ల", "వ", "శ", "ష", "స", "హ", "ళ", "క్ష", "జ్ఞ", "ఱ", "ా", "ి", "ీ", "ు", "ూ", "ృ", "ె", "ే", "ై", "ొ", "ో", "ౌ",
                "గు", "చూ", "తే", "నా", "వీ", "బు", "లో", "క్షు", "ద్ర"
            ]) - set(unique_syllables))
        else:
            distractors_pool = []

        target_total_buttons = 12
        num_distractors_needed = max(0, target_total_buttons - len(unique_syllables))

        # Sample distractors, ensuring we don't try to sample more than available
        random_distractors = random.sample(distractors_pool, min(len(distractors_pool), num_distractors_needed))

        all_blocks = unique_syllables + random_distractors
        random.shuffle(all_blocks)

        for syllable in all_blocks:
            btn = MDRaisedButton(
                text=syllable,
                font_name=self.non_english_answer_label.font_name,
                size_hint=(None, None),
                size=(dp(60), dp(55)), # Consistent button size
                # Changed to MD2-compatible colors
                md_bg_color=self.app.theme_cls.primary_light, # Using primary_light
                text_color=self.app.theme_cls.primary_color, # Using primary_color for text
                elevation=2 # Slight elevation
            )
            btn.bind(on_release=self.add_letter)
            self.letter_grid.add_widget(btn)

    def add_letter(self, instance):
        """
        Appends a selected letter/syllable to the current answer string.
        Limits the total number of characters to 10 for better visibility.
        """
        current_input_list = None
        if self.language == "Tamil":
            current_input_list = self.tamil_syllables
        elif self.language == "Hindi":
            current_input_list = self.hindi_syllables
        elif self.language == "Telugu":
            current_input_list = self.telugu_syllables

        if current_input_list is not None:
            if len(current_input_list) < 10:
                current_input_list.append(instance.text)
                combined = "".join(current_input_list)
                self.non_english_answer_label.text = unicodedata.normalize("NFC", combined)


    def clear_non_english_input(self, instance):
        """Clears the non-English input buffer and display."""
        self.tamil_syllables.clear()
        self.hindi_syllables.clear()
        self.telugu_syllables.clear()
        self.non_english_answer_label.text = ""

    def backspace_non_english_input(self, instance):
        """Removes the last entered letter/syllable from the non-English input."""
        combined = ""
        if self.language == "Tamil" and self.tamil_syllables:
            self.tamil_syllables.pop()
            combined = "".join(self.tamil_syllables)
        elif self.language == "Hindi" and self.hindi_syllables:
            self.hindi_syllables.pop()
            combined = "".join(self.hindi_syllables)
        elif self.language == "Telugu" and self.telugu_syllables:
            self.telugu_syllables.pop()
            combined = "".join(self.telugu_syllables)

        self.non_english_answer_label.text = unicodedata.normalize("NFC", combined)

    def next_question(self, instance):
        """Processes the user's answer, updates score, and loads the next question or ends the test."""
        answer = ""
        if self.language == "English":
            answer = self.answer_input.text.strip().lower()
        elif self.language == "Tamil":
            answer = unicodedata.normalize("NFC", "".join(self.tamil_syllables).strip())
        elif self.language == "Hindi":
            answer = unicodedata.normalize("NFC", "".join(self.hindi_syllables).strip())
        elif self.language == "Telugu":
            answer = unicodedata.normalize("NFC", "".join(self.telugu_syllables).strip())

        self.user_answers.append((self.current_question, answer))
        correct_answer = self.correct_answers.get(self.language, {}).get(self.current_question, "").strip()

        # Compare answers (case-insensitive for English, normalized for others)
        if answer == unicodedata.normalize("NFC", correct_answer):
            self.score += 1

        if self.current_question < self.max_questions:
            self.current_question += 1
            self.load_question()
        else:
            self._end_test()

    def _end_test(self):
        """Handles the end of the test, displaying results and navigating back."""
        print("\n--- Near Vision Test Complete (Right Eye) ---")
        print(f"Final Score: {self.score}/{self.max_questions}")
        print("Your Answers vs. Correct Answers:")
        for q, user_ans in self.user_answers:
            expected_ans = self.correct_answers.get(self.language, {}).get(q, "N/A")
            status = "CORRECT" if unicodedata.normalize("NFC", user_ans) == unicodedata.normalize("NFC", expected_ans) else "INCORRECT"
            print(f"   Q{q}: You typed '{user_ans}' (Expected: '{expected_ans}') - {status}")
        print("------------------------------------------")

        if self.score == self.max_questions:
            remark = "Excellent"
            result_text = f"You scored {self.score} out of {self.max_questions}\n\nGreat news—your near vision is perfectly normal.\nYou correctly identified all the test patterns."
            dialog_title = "Vision Normal!"
            dialog_icon = "check-circle" # Success icon
            dialog_icon_color = self.app.theme_cls.primary_color
        else:
            remark = "Needs Attention"
            result_text = f"You scored {self.score} out of {self.max_questions}\n\nHeads up!\nIt looks like you had trouble with some of the words in the test. This might mean you have a near vision deficiency. It’s quite common, but to be sure, please consider seeing an eye specialist."
            dialog_title = "Vision Check Recommended"
            dialog_icon = "alert-circle" # Warning icon
            dialog_icon_color = self.app.theme_cls.error_color

        app = MDApp.get_running_app()
        if hasattr(app, 'email') and collection is not None:
            try:
                collection.update_one(
                    {"email": app.email},
                    {"$set": {
                        "Near_vision_results.right_eye_score": self.score,
                        "Near_vision_results.right_eye_remark": remark
                    }},
                    upsert=True
                )
                print("Database updated successfully.")
            except Exception as e:
                print(f"Error updating database: {e}")

        # Show a dialog with the score before navigating
        dialog = MDDialog(
            title=dialog_title,
            content_cls=MDBoxLayout(
                MDLabel(
                    halign="center",
                    font_size="64sp",
                    theme_text_color="Custom",
                    text_color=dialog_icon_color,
                    markup=True,
                    size_hint_y=None,
                    height=dp(80)
                ),
                MDLabel(
                    text=result_text,
                    halign="center",
                    adaptive_height=True,
                    padding=dp(10)
                ),
                orientation='vertical',
                spacing=dp(10)
            ),
            buttons=[
                MDFlatButton(
                    text="OK",
                    on_release=lambda x: (dialog.dismiss(), setattr(self.manager, 'current', 'near_vision_test')),
                    text_color=self.app.theme_cls.primary_color
                )
            ]
        )
        dialog.open()



class NearVisionLeft(Screen):
    # Multiplier to artificially increase content height for testing scrolling.
    # Set to 1.0 for normal behavior. Set to >1.0 to force content overflow.
    TEST_OVERFLOW_HEIGHT_MULTIPLIER = 1.0 # This multiplier won't be as directly relevant now for the overall screen height,
                                        # but keep it if you use it elsewhere.

    # Kivy properties for dynamic UI updates
    language = StringProperty(None)
    current_question = 1
    max_questions = 6
    user_answers = []
    score = 0

    # Stores individual characters/syllables typed for non-English languages
    tamil_syllables = []
    hindi_syllables = []
    telugu_syllables = []

    correct_answers = {
        "English": {
            1: "bharat", 2: "anand", 3: "pooja",
            4: "ahmed", 5: "netaji", 6: "nagpur"
        },
        "Tamil": {
            1: "பரத்", 2: "ஆனந்த்", 3: "பூஜா",
            4: "அஹ்மத்", 5: "நிர்மல்", 6: "நாக்பூர்"
        },
        "Hindi": {
            1: "भारत", 2: "आनंद", 3: "पूजा",
            4: "अहमad", 5: "नेताजी", 6: "नागपुर"
        },
        "Telugu": {
            1: "భారత్", 2: "ఆనంద్", 3: "పూజ",
            4: "అహ్మద్", 5: "నేతాజీ", 6: "నాగపూర్"
        }
    }

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # Determine theme style for dynamic icon coloring
        self.app = MDApp.get_running_app()
        self.is_light_theme = self.app.theme_cls.theme_style == "Light"

        self._create_ui()
        self.bind(language=self.on_language_change) # Bind to language property for updates

    def _create_ui(self):
        """Builds the main user interface elements for the screen."""
        # Create a ScrollView that will encompass the entire screen's content
        self.main_scroll_view = ScrollView(
            do_scroll_y=True,
            size_hint=(1, 1)
        )

        self.root_layout = MDBoxLayout(
            orientation='vertical',
            padding=dp(20), # Uniform padding
            spacing=dp(10),
            size_hint_y=None, # Crucial: Let the BoxLayout determine its height based on content
            adaptive_height=True # KivyMD specific: makes size_hint_y=None work well
        )
        # Bind minimum_height so the ScrollView knows the content's total height
        self.root_layout.bind(minimum_height=self.root_layout.setter('height'))


        # Set a white background for the root layout (now inside the scroll view)
        # Note: The background of the scrollable area itself.
        with self.root_layout.canvas.before:
            Color(1, 1, 1, 1) # White background
            self.rect = Rectangle(pos=self.root_layout.pos, size=self.root_layout.size)
        self.root_layout.bind(pos=self._update_rect, size=self._update_rect)


        self.root_layout.add_widget(self._create_title_and_language_labels())
        # Add the main content directly to root_layout, no longer a separate ScrollView
        self.root_layout.add_widget(self._create_word_display_card())
        self.root_layout.add_widget(self._create_english_input_card())
        self.root_layout.add_widget(self._create_non_english_input_card())

        # Add padding at the bottom for the next button to not stick to the edge
        self.root_layout.add_widget(MDBoxLayout(size_hint_y=None, height=dp(20)))

        self.root_layout.add_widget(self._create_next_button())

        # Add the root_layout to the main_scroll_view
        self.main_scroll_view.add_widget(self.root_layout)
        # Add the main_scroll_view to the screen
        self.add_widget(self.main_scroll_view)

    def _update_rect(self, *args):
        """Updates the background rectangle position and size with the root layout."""
        self.rect.pos = self.root_layout.pos
        self.rect.size = self.root_layout.size

    def _create_title_and_language_labels(self):
        """Creates and returns a layout with title and language labels."""
        label_layout = MDBoxLayout(
            orientation='vertical',
            spacing=dp(5), # Reduced spacing for a tighter look
            size_hint_y=None,
            adaptive_height=True # Let height adapt to content
        )
        self.title_label = MDLabel(
            halign="center",
            font_style="H5",
            markup=True, # Enable markup for bold text
            color=(0, 0, 0, 1) # Black text for light theme
        )
        self.language_label = MDLabel(
            text="Language: Not set", # Default text
            halign="center",
            theme_text_color="Secondary", # Subtle secondary color
            font_style="Body1"
        )
        label_layout.add_widget(self.title_label)
        label_layout.add_widget(self.language_label)
        return label_layout

    # Removed _create_scrollable_content as it's no longer needed,
    # the entire screen is now scrollable.

    def _create_word_display_card(self):
        """Creates and returns the card for displaying the word/image."""
        self.word_display_card = MDCard(
            orientation='vertical',
            padding=dp(20),
            spacing=dp(15), # Increased spacing within the card
            size_hint_y=None,
            height=dp(200), # Original height for the card
            elevation=4, # More pronounced shadow
            line_color=self.app.theme_cls.primary_color, # Primary color border
            line_width=1.5, # Thicker border
            md_bg_color=[1, 1, 1, 1], # White background for the card
            radius=[dp(12),] # Rounded corners
        )
        self.image_widget = KivyImage(
            source="",
            size_hint=(None, None),
            size=(dp(300), dp(150)), # Retained original image size
            pos_hint={"center_x": 0.5, "center_y": 0.5}, # Center both ways
            allow_stretch=False,
            keep_ratio=True
        )

        self.word_display_card.add_widget(self.image_widget)
        return self.word_display_card

    def _create_english_input_card(self):
        """Creates and returns the card for English text input."""
        self.english_input_card = MDCard(
            orientation='vertical',
            padding=dp(20),
            spacing=dp(10),
            size_hint_y=None,
            height=dp(110), # Slightly more height
            elevation=4,
            line_color=self.app.theme_cls.primary_color,
            line_width=1.5,
            md_bg_color=[1, 1, 1, 1],
            radius=[dp(12),]
        )
        self.answer_input = MDTextField(
            hint_text="Type what you see...",
            mode="fill", # Modern fill mode for text field
            size_hint_y=None,
            height=dp(60),
            font_size="18sp", # Slightly larger font
        )
        # Set these properties after the main initialization for robustness
        self.answer_input.fill_color = self.app.theme_cls.bg_normal
        self.answer_input.line_color_normal = self.app.theme_cls.primary_color
        self.answer_input.text_color = self.app.theme_cls.text_color # Ensure text color is set by theme

        self.english_input_card.add_widget(self.answer_input)
        return self.english_input_card

    def _create_non_english_input_card(self):
        """Creates and returns the card for non-English keypad input."""
        self.non_english_input_card = MDCard(
            orientation="vertical",
            spacing=dp(20),
            padding = 35,
            size_hint=(1, None),
            adaptive_height=True,
            elevation=4,
            line_color=self.app.theme_cls.primary_color,
            line_width=1.5,
            md_bg_color=[1, 1, 1, 1],
            radius=[dp(12),]
        )
        self.non_english_answer_label = MDLabel(
            text="", halign="center",
            font_name="TeluguFont" if self.language == "Telugu" else "HindiFont" if self.language == "Hindi" else "TamilFont",
            theme_text_color="Custom", text_color=(0, 0, 0, 1), font_size="32sp", # Larger font for answer
            size_hint_y=None, height=dp(60), # More height for display
            markup=True
        )
        self.non_english_input_card.add_widget(self.non_english_answer_label)

        self.letter_grid = MDGridLayout(
            cols=3,
            spacing=dp(5), 
            adaptive_height=True,
            size_hint_y=None,
            row_force_default=False,
            row_default_height=dp(58) # Slightly larger buttons
        )
        self.letter_grid.bind(minimum_height=self.letter_grid.setter('height'))
        self.non_english_input_card.add_widget(self.letter_grid)

        control_buttons = MDBoxLayout(
            size_hint=(1, None),
            height=dp(55), # More height for control buttons
            spacing=dp(15), # Spacing between control buttons
            padding=(0, dp(10), 0, 0) # Top padding
        )
        clear_btn = MDRaisedButton(
            text="Clear",
            size_hint_x=0.5,
            md_bg_color=self.app.theme_cls.accent_color # Accent color for clear
        )
        clear_btn.bind(on_release=self.clear_non_english_input)
        backspace_btn = MDRaisedButton(
            text="⌫",
            size_hint_x=0.5,
            md_bg_color=self.app.theme_cls.error_color # Error color for backspace
        )
        backspace_btn.bind(on_release=self.backspace_non_english_input)
        control_buttons.add_widget(clear_btn)
        control_buttons.add_widget(backspace_btn)
        self.non_english_input_card.add_widget(control_buttons)

        self.non_english_input_card.opacity = 0
        self.non_english_input_card.disabled = True

        return self.non_english_input_card

    def _create_next_button(self):
        """Creates and returns the 'Next' button."""
        self.next_button = MDRaisedButton(
            text="NEXT", # Uppercase text
            font_style="Button",
            pos_hint={"center_x": 0.5},
            size_hint=(0.5, None), # Wider button
            height=dp(52), # Taller button
            md_bg_color=self.app.theme_cls.primary_color, # Primary color for main action
            line_color=(0,0,0,0), # No line
            shadow_radius=dp(8), # More prominent shadow
            shadow_offset=(0, dp(2))
        )
        self.next_button.bind(on_release=self.next_question)
        return self.next_button

    def go_back(self, instance):
        """Navigates back to the near_vision_test screen."""
        self.manager.current = 'near_vision_test'

    def on_language_change(self, instance, value):
        """Called when the language property changes, updates UI accordingly."""
        self.update_answer_label_font()
        # Only setup non-english letters if it's a non-english language
        if value in ["Tamil", "Hindi", "Telugu"]:
            self.setup_non_english_letters()

    def update_answer_label_font(self):
        """Updates the font of the non-English answer label based on the selected language."""
        self.non_english_answer_label.font_name = (
            "TeluguFont" if self.language == "Telugu" else
            "HindiFont" if self.language == "Hindi" else
            "TamilFont"
        )
        self.non_english_answer_label.texture_update()

    def set_test_language(self, language: str):
        """
        Sets the language for the test and reconfigures the UI accordingly.
        Args:
            language (str): The selected language (e.g., "English", "Tamil").
        """
        self.language = language
        self.current_question = 1
        self.user_answers = []
        self.score = 0

        self.tamil_syllables.clear()
        self.hindi_syllables.clear()
        self.telugu_syllables.clear()

        # Show/hide relevant input cards
        if language == "English":
            self.english_input_card.opacity = 1
            self.english_input_card.disabled = False
            self.non_english_input_card.opacity = 0
            self.non_english_input_card.disabled = True
        elif language in ["Tamil", "Hindi", "Telugu"]:
            self.english_input_card.opacity = 0
            self.english_input_card.disabled = True
            self.non_english_input_card.opacity = 1
            self.non_english_input_card.disabled = False
            # Font update and keypad setup are now handled by on_language_change binding
        self.load_question()

    def load_question(self):
        """Loads the current question's image and resets input fields."""
        img_dir = {
            "English": "nv_english",
            "Tamil": "nv_tamil",
            "Hindi": "nv_hindi",
            "Telugu": "nv_telugu"
        }.get(self.language, "nv_english")

        # The problem was likely here - the path needs to start from the root of where Kivy expects assets
        # If 'assets' is a top-level folder in your project, the path should be relative to it.
        # So, it should be f"assets/images/{img_dir}/image_{self.current_question}.png"
        self.image_widget.source = f"{img_dir}/image_{self.current_question}.png"
        self.image_widget.reload()

        self.answer_input.text = ""
        self.clear_non_english_input(None)

        # setup_non_english_letters is now triggered by on_language_change,
        # but calling it here again ensures it reloads for each question
        if self.language in ["Tamil", "Hindi", "Telugu"]:
            self.setup_non_english_letters()

    def setup_non_english_letters(self):
        """Generates and displays buttons for the non-English keypad."""
        self.letter_grid.clear_widgets()
        correct_word = self.correct_answers.get(self.language, {}).get(self.current_question, "")
        correct_syllables = list(correct_word) # Simple character split for now (adjust for complex scripts if needed)

        unique_syllables = list(set(correct_syllables))

        # Define a pool of distractors specific to each language
        # These lists should be comprehensive and ideally based on common characters
        # or phonemes for the respective languages.
        if self.language == "Tamil":
            distractors_pool = list(set([
                "அ", "ஆ", "இ", "ஈ", "உ", "ஊ", "எ", "ஏ", "ஐ", "ஒ", "ஓ", "ஔ", "க", "ங", "ச", "ஞ", "ட", "ண", "த", "ந",
                "ப", "ம", "ய", "ர", "ல", "வ", "ழ", "ற", "ன", "ஸ்ரீ", "க்", "ங்", "ச்", "ஞ்", "ட்", "ண்", "த்", "ந்",
                "ப்", "ம்", "ய்", "ர்", "ல்", "வ்", "ழ்", "ற்", "ன்", "ா", "ி", "ீ", "ு", "ூ", "ெ", "ே", "ை", "ொ", "ோ", "ௌ",
                "கு", "மு", "தி", "வி", "சி", "கெ", "மே", "தூ", "னை", "ஜோ"
            ]) - set(unique_syllables))
        elif self.language == "Hindi":
            distractors_pool = list(set([
                "अ", "आ", "इ", "ई", "उ", "ऊ", "ऋ", "ए", "ऐ", "ओ", "औ", "क", "ख", "ग", "घ", "ङ", "च", "छ", "ज", "झ",
                "ञ", "ट", "ठ", "ड", "ढ", "ण", "त", "थ", "द", "ध", "न", "प", "फ", "ब", "भ", "म", "य", "र", "ल", "व",
                "श", "ष", "स", "ह", "ा", "ि", "ी", "ु", "ू", "ृ", "े", "ै", "ो", "ौ", "ं", "ः", "्", "क़", "ख़", "ग़", "ज़", "फ़", "ड़", "ढ़",
                "कृ", "रु", "लौ", "कि", "मो", "ते", "सू", "प्र", "शृ"
            ]) - set(unique_syllables))
        elif self.language == "Telugu":
            distractors_pool = list(set([
                "అ", "ఆ", "ఇ", "ఈ", "ఉ", "ఊ", "ఋ", "ఎ", "ఏ", "ఐ", "ఒ", "ఓ", "ఔ", "క", "ఖ", "గ", "ఘ", "ఙ", "చ", "ఛ",
                "జ", "ఝ", "ఞ", "ట", "ఠ", "డ", "ఢ", "ణ", "త", "థ", "ద", "ధ", "న", "ప", "ఫ", "బ", "భ", "మ", "య", "ర",
                "ల", "వ", "శ", "ష", "స", "హ", "ళ", "క్ష", "జ్ఞ", "ఱ", "ా", "ి", "ీ", "ు", "ూ", "ృ", "ె", "ే", "ై", "ొ", "ో", "ౌ",
                "గు", "చూ", "తే", "నా", "వీ", "బు", "లో", "క్షు", "ద్ర"
            ]) - set(unique_syllables))
        else:
            distractors_pool = []

        target_total_buttons = 12
        num_distractors_needed = max(0, target_total_buttons - len(unique_syllables))

        # Sample distractors, ensuring we don't try to sample more than available
        random_distractors = random.sample(distractors_pool, min(len(distractors_pool), num_distractors_needed))

        all_blocks = unique_syllables + random_distractors
        random.shuffle(all_blocks)

        for syllable in all_blocks:
            btn = MDRaisedButton(
                text=syllable,
                font_name=self.non_english_answer_label.font_name,
                size_hint=(None, None),
                size=(dp(60), dp(55)), # Consistent button size
                # Changed to MD2-compatible colors
                md_bg_color=self.app.theme_cls.primary_light, # Using primary_light
                text_color=self.app.theme_cls.primary_color, # Using primary_color for text
                elevation=2 # Slight elevation
            )
            btn.bind(on_release=self.add_letter)
            self.letter_grid.add_widget(btn)

    def add_letter(self, instance):
        """
        Appends a selected letter/syllable to the current answer string.
        Limits the total number of characters to 10 for better visibility.
        """
        current_input_list = None
        if self.language == "Tamil":
            current_input_list = self.tamil_syllables
        elif self.language == "Hindi":
            current_input_list = self.hindi_syllables
        elif self.language == "Telugu":
            current_input_list = self.telugu_syllables

        if current_input_list is not None:
            if len(current_input_list) < 10:
                current_input_list.append(instance.text)
                combined = "".join(current_input_list)
                self.non_english_answer_label.text = unicodedata.normalize("NFC", combined)


    def clear_non_english_input(self, instance):
        """Clears the non-English input buffer and display."""
        self.tamil_syllables.clear()
        self.hindi_syllables.clear()
        self.telugu_syllables.clear()
        self.non_english_answer_label.text = ""

    def backspace_non_english_input(self, instance):
        """Removes the last entered letter/syllable from the non-English input."""
        combined = ""
        if self.language == "Tamil" and self.tamil_syllables:
            self.tamil_syllables.pop()
            combined = "".join(self.tamil_syllables)
        elif self.language == "Hindi" and self.hindi_syllables:
            self.hindi_syllables.pop()
            combined = "".join(self.hindi_syllables)
        elif self.language == "Telugu" and self.telugu_syllables:
            self.telugu_syllables.pop()
            combined = "".join(self.telugu_syllables)

        self.non_english_answer_label.text = unicodedata.normalize("NFC", combined)

    def next_question(self, instance):
        """Processes the user's answer, updates score, and loads the next question or ends the test."""
        answer = ""
        if self.language == "English":
            answer = self.answer_input.text.strip().lower()
        elif self.language == "Tamil":
            answer = unicodedata.normalize("NFC", "".join(self.tamil_syllables).strip())
        elif self.language == "Hindi":
            answer = unicodedata.normalize("NFC", "".join(self.hindi_syllables).strip())
        elif self.language == "Telugu":
            answer = unicodedata.normalize("NFC", "".join(self.telugu_syllables).strip())

        self.user_answers.append((self.current_question, answer))
        correct_answer = self.correct_answers.get(self.language, {}).get(self.current_question, "").strip()

        # Compare answers (case-insensitive for English, normalized for others)
        if answer == unicodedata.normalize("NFC", correct_answer):
            self.score += 1

        if self.current_question < self.max_questions:
            self.current_question += 1
            self.load_question()
        else:
            self._end_test()

    def _end_test(self):
        """Handles the end of the test, displaying results and navigating back."""
        print("\n--- Near Vision Test Complete (left Eye) ---")
        print(f"Final Score: {self.score}/{self.max_questions}")
        print("Your Answers vs. Correct Answers:")
        for q, user_ans in self.user_answers:
            expected_ans = self.correct_answers.get(self.language, {}).get(q, "N/A")
            status = "CORRECT" if unicodedata.normalize("NFC", user_ans) == unicodedata.normalize("NFC", expected_ans) else "INCORRECT"
            print(f"   Q{q}: You typed '{user_ans}' (Expected: '{expected_ans}') - {status}")
        print("------------------------------------------")

        if self.score == self.max_questions:
            remark = "Excellent"
            result_text = f"You scored {self.score} out of {self.max_questions}\n\nGreat news—your near vision is perfectly normal.\nYou correctly identified all the test patterns."
            dialog_title = "Vision Normal!"
            dialog_icon = "check-circle" # Success icon
            dialog_icon_color = self.app.theme_cls.primary_color
        else:
            remark = "Needs Attention"
            result_text = f"You scored {self.score} out of {self.max_questions}\n\nHeads up!\nIt looks like you had trouble with some of the words in the test. This might mean you have a near vision deficiency. It’s quite common, but to be sure, please consider seeing an eye specialist."
            dialog_title = "Vision Check Recommended"
            dialog_icon = "alert-circle" # Warning icon
            dialog_icon_color = self.app.theme_cls.error_color

        app = MDApp.get_running_app()
        if hasattr(app, 'email') and collection is not None:
            try:
                collection.update_one(
                    {"email": app.email},
                    {"$set": {
                        "Near_vision_results.left_eye_score": self.score,
                        "Near_vision_results.left_eye_remark": remark
                    }},
                    upsert=True
                )
                print("Database updated successfully.")
            except Exception as e:
                print(f"Error updating database: {e}")

        # Show a dialog with the score before navigating
        dialog = MDDialog(
            title=dialog_title,
            content_cls=MDBoxLayout(
                MDLabel(
                    halign="center",
                    font_size="64sp",
                    theme_text_color="Custom",
                    text_color=dialog_icon_color,
                    markup=True,
                    size_hint_y=None,
                    height=dp(80)
                ),
                MDLabel(
                    text=result_text,
                    halign="center",
                    adaptive_height=True,
                    padding=dp(10)
                ),
                orientation='vertical',
                spacing=dp(10)
            ),
            buttons=[
                MDFlatButton(
                    text="OK",
                    on_release=lambda x: (dialog.dismiss(), setattr(self.manager, 'current', 'near_vision_test')),
                    text_color=self.app.theme_cls.primary_color
                )
            ]
        )
        dialog.open()



class DistanceVisionTestScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.selected_test_type = None  # To store the chosen test type

        app = MDApp.get_running_app()
        theme_cls = app.theme_cls
        is_light = theme_cls.theme_style == "Light"

        self.root_layout = MDBoxLayout(
            orientation='vertical',
            padding=[20, 40, 20, 30],
            spacing=30,
            size_hint=(1, 1)
        )

        # Background color with translucent blue
        with self.root_layout.canvas.before:
            Color(0, 0.486, 1, 0.24)
            self.rect = Rectangle(pos=self.root_layout.pos, size=self.root_layout.size)
        self.root_layout.bind(pos=self._update_rect, size=self._update_rect)

        # Top bar with back button
        top_bar = MDBoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=dp(56),
            md_bg_color=[0, 0, 0, 0]
        )
        back_button = MDIconButton(
            icon="arrow-left",
            size_hint=(None, None),
            icon_size="32dp",
            theme_icon_color="Custom",
            icon_color=[0, 0, 0, 1] if is_light else [1, 1, 1, 1],
            md_bg_color=[0.9, 0.9, 0.9, 0.15] if is_light else [0.3, 0.3, 0.3, 0.15]
        )
        back_button.bind(on_release=self.go_back)
        top_bar.add_widget(back_button)
        self.root_layout.add_widget(top_bar)

        # Title
        self.root_layout.add_widget(MDLabel(
            text="Distance Vision Test",
            halign="center",
            font_style="H5",
            size_hint_y=None,
            height=dp(60),
            theme_text_color="Primary",
            font_name="Roboto"
        ))
        
        # This label's text will be updated dynamically
        self.instruction_label = MDLabel(
            text="Start by selecting a test type.",
            halign="center",
            font_style="Body2",
            size_hint_y=None,
            height=dp(60),
            theme_text_color="Primary",
            font_name="Roboto"
        )
        self.root_layout.add_widget(self.instruction_label)

        # Card for buttons
        self.card = MDCard(
            orientation='vertical',
            padding=dp(15),
            spacing=dp(20),
            size_hint=(0.85, None),
            height=dp(150),
            pos_hint={'center_x': 0.5},
            md_bg_color=[1, 1, 1, 1] if is_light else [0.25, 0.25, 0.25, 1],
            radius=[12, 12, 12, 12],
            elevation=4
        )
        self.root_layout.add_widget(self.card)

        # Test type selection button
        self.test_type_button = MDRaisedButton(
            text="Select Test Type",
            size_hint=(1, None),
            height=dp(48),
            md_bg_color=theme_cls.primary_color,
            text_color=[1, 1, 1, 1],
            font_size="15sp",
            font_name="Roboto",
        )
        self.test_type_button.bind(on_release=self.show_test_type_menu)
        self.card.add_widget(self.test_type_button)

        self.add_widget(self.root_layout)

    def _update_rect(self, *args):
        self.rect.pos = self.root_layout.pos
        self.rect.size = self.root_layout.size

    def go_back(self, instance):
        self.manager.current = 'main'

    def show_test_type_menu(self, instance):
        menu_items = [
            {
                "viewclass": "OneLineListItem",
                "text": "Sloan Letters",
                "on_release": lambda x="Sloan Letters": self.set_test_type(x),
            },
            {
                "viewclass": "OneLineListItem",
                "text": "Numbers",
                "on_release": lambda x="Numbers": self.set_test_type(x),
            },
            
        ]
        self.menu = MDDropdownMenu(
            caller=self.test_type_button,
            items=menu_items,
            width_mult=4,
        )
        self.menu.open()

    def set_test_type(self, test_type):
        self.selected_test_type = test_type
        self.menu.dismiss()
        self.display_eye_buttons()

    def display_eye_buttons(self):
        # Clear existing buttons in the card, keeping only the test type button
        self.card.clear_widgets()
        self.card.add_widget(self.test_type_button)

        app = MDApp.get_running_app()
        theme_cls = app.theme_cls

        # Add "Right Eye Test" button
        right_eye_button = MDRaisedButton(
            text="Right Eye Test",
            size_hint=(1, None),
            height=dp(48),
            md_bg_color=theme_cls.primary_color,
            text_color=[1, 1, 1, 1],
            font_size="15sp",
            font_name="Roboto",
        )
        right_eye_button.bind(on_release=lambda x: self.start_test('right_eye_test_dv'))
        self.card.add_widget(right_eye_button)

        # Add "Left Eye Test" button
        left_eye_button = MDRaisedButton(
            text="Left Eye Test",
            size_hint=(1, None),
            height=dp(48),
            md_bg_color=theme_cls.primary_color,
            text_color=[1, 1, 1, 1],
            font_size="15sp",
            font_name="Roboto",
        )
        left_eye_button.bind(on_release=lambda x: self.start_test('left_eye_test_dv'))
        self.card.add_widget(left_eye_button)

        # Update the instruction text
        self.instruction_label.text = f"Proceed with the eye tests using {self.selected_test_type}."

    def start_test(self, test_screen_name):
        """
        Navigates to the specified test screen and passes the selected test type.
        """
        if self.manager:
            target_screen = self.manager.get_screen(test_screen_name)
            if target_screen and hasattr(target_screen, 'set_test_type'):
                target_screen.set_test_type(self.selected_test_type)
            
            print(f"Starting {test_screen_name} with {self.selected_test_type} test chart.")
            self.manager.current = test_screen_name
        else:
            print("ScreenManager not available.")




class RightEyeTestScreenDV(Screen):
    """
    A KivyMD screen for performing a right eye vision test.
    This screen dynamically generates test charts for three types:
    Sloan Letters, Numbers, and Tumbling E (image-based).
    """

    # Kivy properties to store test state
    test_type = StringProperty('Sloan Letters')
    current_level = NumericProperty(0)
    last_correct_level = NumericProperty(0)

    # Predefined font sizes and character counts for the 6 levels
    font_sizes = [72, 60, 48, 36, 30, 24]
    level_char_counts = [1, 2, 3, 4, 5, 6]

    # Character sets for each test type
    SLOAN_LETTERS = ['C', 'D', 'H', 'K', 'N', 'O', 'R', 'S', 'V', 'Z']

    # Image paths for Tumbling E (add these images in assets/)
    TUMBLING_E_IMAGES = {
        0: "assets/tumbling_e_0.png",     # Normal E
        90: "assets/tumbling_e_90.png",   # Rotated right
        180: "assets/tumbling_e_180.png", # Upside down
        270: "assets/tumbling_e_270.png"  # Rotated left
    }

    def __init__(self, **kwargs):
        """Initializes the UI elements and state variables."""
        super().__init__(**kwargs)

        # Get app theme for color styling
        app = MDApp.get_running_app()
        theme_cls = app.theme_cls
        is_light = theme_cls.theme_style == "Light"

        # Main layout container
        self.root_layout = MDBoxLayout(
            orientation='vertical',
            padding=[20, 40, 20, 30],
            spacing=20,
            size_hint=(1, 1)
        )

        # Background color with translucent blue effect
        with self.root_layout.canvas.before:
            Color(0, 0.486, 1, 0.24)
            self.rect = Rectangle(pos=self.root_layout.pos, size=self.root_layout.size)
        self.root_layout.bind(pos=self._update_rect, size=self._update_rect)

        # Top bar with back button
        top_bar = MDBoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=dp(56),
            md_bg_color=[0, 0, 0, 0]
        )
        back_button = MDIconButton(
            icon="arrow-left",
            size_hint=(None, None),
            icon_size="32dp",
            theme_icon_color="Custom",
            icon_color=[0, 0, 0, 1] if is_light else [1, 1, 1, 1],
            md_bg_color=[0.9, 0.9, 0.9, 0.15] if is_light else [0.3, 0.3, 0.3, 0.15]
        )
        back_button.bind(on_release=self.go_back)
        top_bar.add_widget(back_button)
        self.root_layout.add_widget(top_bar)

        # Title
        self.title_label = MDLabel(
            text="Right Eye Test",
            halign="center",
            font_style="H5",
            size_hint_y=None,
            height=dp(60),
            theme_text_color="Primary",
            font_name="Roboto"
        )
        self.root_layout.add_widget(self.title_label)

        # Instruction/status label
        self.instruction_label = MDLabel(
            text="Please cover your left eye and read the characters.",
            halign="center",
            font_style="Body2",
            size_hint_y=None,
            height=dp(60),
            theme_text_color="Primary",
            font_name="Roboto"
        )
        self.root_layout.add_widget(self.instruction_label)

        # Card for test content and buttons
        self.card = MDCard(
            orientation='vertical',
            padding=dp(15),
            spacing=dp(20),
            size_hint=(0.9, None),
            height=dp(400),
            pos_hint={'center_x': 0.5},
            md_bg_color=[1, 1, 1, 1] if is_light else [0.25, 0.25, 0.25, 1],
            radius=[12, 12, 12, 12],
            elevation=4
        )

        # Test content area inside the card
        self.test_content_layout = MDBoxLayout(
            orientation='vertical',
            padding=dp(10),
            spacing=dp(10),
            size_hint=(1, 1)
        )
        self.card.add_widget(self.test_content_layout)

        # Create a persistent label for Sloan and Numbers tests
        self.sloan_numbers_label = MDLabel(
            text="",
            halign="center",
            font_size=72,
            theme_text_color="Primary",
            font_name="Roboto"
        )

        # Buttons layout
        self.buttons_layout = MDBoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=dp(48),
            spacing=dp(10)
        )
        self.correct_button = MDRaisedButton(
            text="Correct",
            size_hint=(1, None),
            height=dp(48),
            md_bg_color=theme_cls.primary_color,
            text_color=[1, 1, 1, 1],
            font_size="15sp",
            on_release=self.on_correct
        )
        self.wrong_button = MDRaisedButton(
            text="Wrong",
            size_hint=(1, None),
            height=dp(48),
            md_bg_color=theme_cls.error_color,
            text_color=[1, 1, 1, 1],
            font_size="15sp",
            on_release=self.on_wrong
        )
        self.buttons_layout.add_widget(self.correct_button)
        self.buttons_layout.add_widget(self.wrong_button)

        self.card.add_widget(self.buttons_layout)
        self.root_layout.add_widget(self.card)

        # Add all widgets to the screen
        self.add_widget(self.root_layout)

    def on_enter(self, *args):
        self.reset_test()

    def set_test_type(self, test_type):
        self.test_type = test_type
        self.title_label.text = f"Right Eye Test - {self.test_type}"

    def reset_test(self):
        self.current_level = 0
        self.last_correct_level = 0
        self.generate_test_content()
        self.instruction_label.text = "Please cover your left eye and read the characters."
        self.correct_button.disabled = False
        self.wrong_button.disabled = False

    def _update_rect(self, *args):
        self.rect.pos = self.root_layout.pos
        self.rect.size = self.root_layout.size

    def go_back(self, instance):
        self.manager.current = 'distance_vision_test'

    def generate_test_content(self):
        self.test_content_layout.clear_widgets()

        if self.current_level >= len(self.level_char_counts):
            self.show_results()
            return

        current_char_count = self.level_char_counts[self.current_level]

        if self.test_type == 'Tumbling E':
            # Outer layout centers the row inside the card
            outer_layout = MDBoxLayout(
                orientation='vertical',
                size_hint=(1, 1),
                pos_hint={'center_x': 0.5, 'center_y': 0.5}
            )

            line_layout = MDBoxLayout(
                orientation='horizontal',
                spacing=dp(15),
                size_hint=(None, None),
                pos_hint={'center_x': 0.5, 'center_y': 0.5}
            )

            for _ in range(current_char_count):
                angle = random.choice([0, 90, 180, 270])
                img_path = self.TUMBLING_E_IMAGES[angle]
                e_img = KivyImage(
                    source=img_path,
                    allow_stretch=True,
                    keep_ratio=True,
                    size_hint=(None, None),
                    size=(self.font_sizes[self.current_level], self.font_sizes[self.current_level])
                )
                line_layout.add_widget(e_img)

            outer_layout.add_widget(line_layout)
            self.test_content_layout.add_widget(outer_layout)

        else:
            current_font_size = self.font_sizes[self.current_level]

            if self.test_type == 'Sloan Letters':
                generated_chars = random.sample(self.SLOAN_LETTERS, k=current_char_count)
            elif self.test_type == 'Numbers':
                generated_chars = random.sample(string.digits, k=current_char_count)
            else:
                generated_chars = []

            text_to_display = " ".join(generated_chars)
            self.sloan_numbers_label.text = text_to_display
            self.sloan_numbers_label.font_size = current_font_size
            self.test_content_layout.add_widget(self.sloan_numbers_label)

        self.instruction_label.text = f"Level {self.current_level + 1} of 6"

    def on_correct(self, instance):
        self.last_correct_level = self.current_level + 1
        self.current_level += 1
        self.generate_test_content()

    def on_wrong(self, instance):
        self.show_results()

    def show_results(self):
        self.test_content_layout.clear_widgets()

        result_text = "Test Completed.\n"
        if self.last_correct_level > 0:
            result_text += f"Last correctly answered level: {self.last_correct_level}"
        else:
            result_text += "You did not pass any levels."

        result_label = MDLabel(
            text=result_text,
            halign="center",
            font_style="H5",
            theme_text_color="Primary",
            font_name="Roboto"
        )
        self.test_content_layout.add_widget(result_label)

        self.correct_button.disabled = True
        self.wrong_button.disabled = True



class LeftEyeTestScreenDV(Screen):
    """
    A KivyMD screen for performing a left eye vision test.
    This screen dynamically generates test charts for three types:
    Sloan Letters, Numbers, and Tumbling E (image-based).
    """

    # Kivy properties to store test state
    test_type = StringProperty('Sloan Letters')
    current_level = NumericProperty(0)
    last_correct_level = NumericProperty(0)

    # Predefined font sizes and character counts for the 6 levels
    font_sizes = [72, 60, 48, 36, 30, 24]
    level_char_counts = [1, 2, 3, 4, 5, 6]

    # Character sets for each test type
    SLOAN_LETTERS = ['C', 'D', 'H', 'K', 'N', 'O', 'R', 'S', 'V', 'Z']

    # Image paths for Tumbling E (add these images in assets/)
    TUMBLING_E_IMAGES = {
        0: "assets/tumbling_e_0.png",     # Normal E
        90: "assets/tumbling_e_90.png",   # Rotated right
        180: "assets/tumbling_e_180.png", # Upside down
        270: "assets/tumbling_e_270.png"  # Rotated left
    }

    def __init__(self, **kwargs):
        """Initializes the UI elements and state variables."""
        super().__init__(**kwargs)

        # Get app theme for color styling
        app = MDApp.get_running_app()
        theme_cls = app.theme_cls
        is_light = theme_cls.theme_style == "Light"

        # Main layout container
        self.root_layout = MDBoxLayout(
            orientation='vertical',
            padding=[20, 40, 20, 30],
            spacing=20,
            size_hint=(1, 1)
        )

        # Background color with translucent blue effect
        with self.root_layout.canvas.before:
            Color(0, 0.486, 1, 0.24)
            self.rect = Rectangle(pos=self.root_layout.pos, size=self.root_layout.size)
        self.root_layout.bind(pos=self._update_rect, size=self._update_rect)

        # Top bar with back button
        top_bar = MDBoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=dp(56),
            md_bg_color=[0, 0, 0, 0]
        )
        back_button = MDIconButton(
            icon="arrow-left",
            size_hint=(None, None),
            icon_size="32dp",
            theme_icon_color="Custom",
            icon_color=[0, 0, 0, 1] if is_light else [1, 1, 1, 1],
            md_bg_color=[0.9, 0.9, 0.9, 0.15] if is_light else [0.3, 0.3, 0.3, 0.15]
        )
        back_button.bind(on_release=self.go_back)
        top_bar.add_widget(back_button)
        self.root_layout.add_widget(top_bar)

        # Title
        self.title_label = MDLabel(
            text="Left Eye Test",
            halign="center",
            font_style="H5",
            size_hint_y=None,
            height=dp(60),
            theme_text_color="Primary",
            font_name="Roboto"
        )
        self.root_layout.add_widget(self.title_label)

        # Instruction/status label
        self.instruction_label = MDLabel(
            text="Please cover your right eye and read the characters.",
            halign="center",
            font_style="Body2",
            size_hint_y=None,
            height=dp(60),
            theme_text_color="Primary",
            font_name="Roboto"
        )
        self.root_layout.add_widget(self.instruction_label)

        # Card for test content and buttons
        self.card = MDCard(
            orientation='vertical',
            padding=dp(15),
            spacing=dp(20),
            size_hint=(0.9, None),
            height=dp(400),
            pos_hint={'center_x': 0.5},
            md_bg_color=[1, 1, 1, 1] if is_light else [0.25, 0.25, 0.25, 1],
            radius=[12, 12, 12, 12],
            elevation=4
        )

        # Test content area inside the card
        self.test_content_layout = MDBoxLayout(
            orientation='vertical',
            padding=dp(10),
            spacing=dp(10),
            size_hint=(1, 1)
        )
        self.card.add_widget(self.test_content_layout)

        # Create a persistent label for Sloan and Numbers tests
        self.sloan_numbers_label = MDLabel(
            text="",
            halign="center",
            font_size=72,
            theme_text_color="Primary",
            font_name="Roboto"
        )

        # Buttons layout
        self.buttons_layout = MDBoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=dp(48),
            spacing=dp(10)
        )
        self.correct_button = MDRaisedButton(
            text="Correct",
            size_hint=(1, None),
            height=dp(48),
            md_bg_color=theme_cls.primary_color,
            text_color=[1, 1, 1, 1],
            font_size="15sp",
            on_release=self.on_correct
        )
        self.wrong_button = MDRaisedButton(
            text="Wrong",
            size_hint=(1, None),
            height=dp(48),
            md_bg_color=theme_cls.error_color,
            text_color=[1, 1, 1, 1],
            font_size="15sp",
            on_release=self.on_wrong
        )
        self.buttons_layout.add_widget(self.correct_button)
        self.buttons_layout.add_widget(self.wrong_button)

        self.card.add_widget(self.buttons_layout)
        self.root_layout.add_widget(self.card)

        # Add all widgets to the screen
        self.add_widget(self.root_layout)

    def on_enter(self, *args):
        self.reset_test()

    def set_test_type(self, test_type):
        self.test_type = test_type
        self.title_label.text = f"Left Eye Test - {self.test_type}"

    def reset_test(self):
        self.current_level = 0
        self.last_correct_level = 0
        self.generate_test_content()
        self.instruction_label.text = "Please cover your right eye and read the characters."
        self.correct_button.disabled = False
        self.wrong_button.disabled = False

    def _update_rect(self, *args):
        self.rect.pos = self.root_layout.pos
        self.rect.size = self.root_layout.size

    def go_back(self, instance):
        self.manager.current = 'distance_vision_test'

    def generate_test_content(self):
        self.test_content_layout.clear_widgets()

        if self.current_level >= len(self.level_char_counts):
            self.show_results()
            return

        current_char_count = self.level_char_counts[self.current_level]

        if self.test_type == 'Tumbling E':
            # Outer layout centers the row inside the card
            outer_layout = MDBoxLayout(
                orientation='vertical',
                size_hint=(1, 1),
                pos_hint={'center_x': 0.5, 'center_y': 0.5}
            )

            line_layout = MDBoxLayout(
                orientation='horizontal',
                spacing=dp(15),
                size_hint=(None, None),
                pos_hint={'center_x': 0.5, 'center_y': 0.5}
            )

            for _ in range(current_char_count):
                angle = random.choice([0, 90, 180, 270])
                img_path = self.TUMBLING_E_IMAGES[angle]
                e_img = KivyImage(
                    source=img_path,
                    allow_stretch=True,
                    keep_ratio=True,
                    size_hint=(None, None),
                    size=(self.font_sizes[self.current_level], self.font_sizes[self.current_level])
                )
                line_layout.add_widget(e_img)

            outer_layout.add_widget(line_layout)
            self.test_content_layout.add_widget(outer_layout)

        else:
            current_font_size = self.font_sizes[self.current_level]

            if self.test_type == 'Sloan Letters':
                generated_chars = random.sample(self.SLOAN_LETTERS, k=current_char_count)
            elif self.test_type == 'Numbers':
                generated_chars = random.sample(string.digits, k=current_char_count)
            else:
                generated_chars = []

            text_to_display = " ".join(generated_chars)
            self.sloan_numbers_label.text = text_to_display
            self.sloan_numbers_label.font_size = current_font_size
            self.test_content_layout.add_widget(self.sloan_numbers_label)

        self.instruction_label.text = f"Level {self.current_level + 1} of 6"

    def on_correct(self, instance):
        self.last_correct_level = self.current_level + 1
        self.current_level += 1
        self.generate_test_content()

    def on_wrong(self, instance):
        self.show_results()

    def show_results(self):
        self.test_content_layout.clear_widgets()

        result_text = "Test Completed.\n"
        if self.last_correct_level > 0:
            result_text += f"Last correctly answered level: {self.last_correct_level}"
        else:
            result_text += "You did not pass any levels."

        result_label = MDLabel(
            text=result_text,
            halign="center",
            font_style="H5",
            theme_text_color="Primary",
            font_name="Roboto"
        )
        self.test_content_layout.add_widget(result_label)

        self.correct_button.disabled = True
        self.wrong_button.disabled = True


class ScoresScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        # 💡 Background canvas
        with self.canvas.before:
            Color(rgba=(0, 0.486, 1, 0.24))  # Light lavender background
            self.bg_rect = Rectangle(size=self.size, pos=self.pos)
        self.bind(size=self.update_bg_rect, pos=self.update_bg_rect)

        # 📦 Outer layout for screen
        outer_layout = MDBoxLayout(orientation='vertical', padding=20, spacing=20)

        # 🔙 Back button
        back_button = MDIconButton(icon="arrow-left", pos_hint={"center_x": 0.1}, icon_size="20dp")
        back_button.bind(on_release=self.go_back)
        outer_layout.add_widget(back_button)

        # 🧾 Scrollable area
        self.user_data_layout = MDBoxLayout(
            orientation='vertical',
            spacing=20,
            padding=[20, 10, 20, 10],
            size_hint_y=None,
            
        )
        self.user_data_layout.bind(minimum_height=self.user_data_layout.setter('height'))

        scroll = ScrollView()
        scroll.add_widget(self.user_data_layout)
        outer_layout.add_widget(scroll)

        self.add_widget(outer_layout)

    def update_bg_rect(self, *args):
        self.bg_rect.size = self.size
        self.bg_rect.pos = self.pos

    def on_enter(self):
        self.display_user_data()

    def display_user_data(self):
        self.user_data_layout.clear_widgets()
        app = MDApp.get_running_app()
        email_to_find = getattr(app, 'email', None)

        if not email_to_find:
            self.user_data_layout.add_widget(MDLabel(
                text="User email not available.",
                halign="center",
                theme_text_color="Error",
                size_hint_y=None,
                height=dp(50)
            ))
            return

        try:
            user_data = collection.find_one({"email": email_to_find}, {"_id": 0, "password": 0, "email": 0, "name": 0})
            if not user_data:
                self.user_data_layout.add_widget(MDLabel(
                    text="No test data found.",
                    halign="center",
                    theme_text_color="Error",
                    size_hint_y=None,
                    height=dp(50)
                ))
                return

            for test_key, test_data in user_data.items():
                if isinstance(test_data, dict):
                    card = self.create_test_card(test_key.replace('_', ' ').title(), test_data)
                    self.user_data_layout.add_widget(card)

        except Exception as e:
            print(f"Error fetching data from MongoDB: {e}")
            self.user_data_layout.add_widget(MDLabel(
                text="Error loading scores.",
                halign="center",
                theme_text_color="Error",
                size_hint_y=None,
                height=dp(50)
            ))

    def create_test_card(self, title, test_data):
        card = MDCard(
            orientation='vertical',
            padding=10,
            spacing=10,
            size_hint_y=None,
            elevation=2
        )

        card.bind(minimum_height=card.setter('height'))

        card.add_widget(MDLabel(
            text=f"[b]{title}[/b]",
            markup=True,
            halign="center",
            theme_text_color="Primary",
            font_style="H6",
            size_hint_y=None,
            height=dp(30)
        ))

        for eye in ['left_eye', 'right_eye', 'eyes', 'both_eye']:
            eye_fields = {k: v for k, v in test_data.items() if k.startswith(eye)}
            if not eye_fields:
                continue

            card.add_widget(MDLabel(
                text=f"[b]{eye.replace('_', ' ').title()}[/b]",
                markup=True,
                theme_text_color="Secondary",
                halign="center",
                size_hint_y=None,
                height=dp(25)
            ))

            table = GridLayout(cols=2, spacing=10, size_hint_y=None)
            table.bind(minimum_height=table.setter('height'))

            for key, value in eye_fields.items():
                label = key.replace(f"{eye}_", "").replace("_", " ").title()
                table.add_widget(MDLabel(
                    text=label,
                    bold=True,
                    halign="center",
                    size_hint_y=None,
                    height=dp(30)
                ))
                table.add_widget(MDLabel(
                    text=str(value),
                    halign="center",
                    size_hint_y=None,
                    height=dp(30)
                ))

            card.add_widget(table)

        return card
    def go_back(self, instance):
        self.manager.current = 'main'



class SimpleMDApp(MDApp):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.user_id = None
        self.user_name = None
        self.email = None
        self.sm = ScreenManager() # Initialize self.sm here

    def build(self):
        self.theme_cls.primary_palette = "Blue"
        self.theme_cls.theme_style = "Light"

        self.sm.add_widget(LoginScreen(name='login'))
        self.sm.add_widget(SignupScreen(name='signup'))
        self.sm.add_widget(MainScreen(name='main'))

        self.sm.add_widget(NearVisionTestScreen(name='near_vision_test'))
        self.sm.add_widget(NearVisionLeft(name='left_eye_test_nv'))
        self.sm.add_widget(NearVisionRight(name='right_eye_test_nv'))

        self.sm.add_widget(ColorVisionTestScreen(name='color_vision_test'))

        self.sm.add_widget(ContrastSensitivityTestScreen(name='contrast_sensitivity_test'))

        self.sm.add_widget(AmslerGridTestScreen(name='amsler_grid_test'))
        self.sm.add_widget(LeftEyeTestScreenAG(name='left_eye_test_ag'))
        self.sm.add_widget(RightEyeTestScreenAG(name='right_eye_test_ag'))

        self.sm.add_widget(StereopsisTestScreen(name='stereopsis_test'))
        self.sm.add_widget(ScoresScreen(name='scores'))
        self.sm.add_widget(LeftEyeTestScreen(name='left_eye_test'))
        self.sm.add_widget(RightEyeTestScreen(name='right_eye_test'))
        self.sm.add_widget(RightEyeTestScreenContrast(name='right_eye_test_contrast'))
        self.sm.add_widget(LeftEyeTestScreenContrast(name='left_eye_test_contrast'))

        self.sm.add_widget(DistanceVisionTestScreen(name='distance_vision_test'))
        self.sm.add_widget(RightEyeTestScreenDV(name='right_eye_test_dv'))
        self.sm.add_widget(LeftEyeTestScreenDV(name="left_eye_test_dv"))
        self.sm.current = 'login'
        return self.sm

if __name__ == '__main__':
    SimpleMDApp().run()
