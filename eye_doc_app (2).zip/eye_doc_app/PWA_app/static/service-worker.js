const CACHE_NAME = 'pwa-app-cache-v1';
const urlsToCache = [
    '/',
    '/static/login_style.css',
    '/static/manifest.json',
    '/static/icons/placeholder.png'
];

// Install event — cache defined files
self.addEventListener('install', event => {
    event.waitUntil(
        caches.open(CACHE_NAME).then(cache => {
        return cache.addAll(urlsToCache);
        })
    );
});

// Activate event — clean up old caches if any
self.addEventListener('activate', event => {
    event.waitUntil(
        caches.keys().then(cacheNames => {
        return Promise.all(
            cacheNames.map(name => {
            if (name !== CACHE_NAME) {
                return caches.delete(name);
            }
            })
        );
        })
    );
});

// Fetch event — try cache first, then network
self.addEventListener('fetch', event => {
    event.respondWith(
        caches.match(event.request).then(response => {
        return response || fetch(event.request);
        })
    );
});
