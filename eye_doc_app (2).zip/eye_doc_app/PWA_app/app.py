from flask import Flask, request, jsonify, render_template, session
from pymongo import MongoClient
from dotenv import load_dotenv
import os
import random

app = Flask(__name__)

app.secret_key = '19020206'

connection_string = "mongodb+srv://dhanushya:frooti@eye-doc-application.c6dvx4u.mongodb.net/?retryWrites=true&w=majority"

if not connection_string:
    raise Exception("MONGO_URI environment variable not set")

client = MongoClient(connection_string)
db = client['EyeDoctor']
collection = db['Credentials']
otp = None

from flask import Flask, render_template, request, redirect, url_for

@app.route('/')
def index():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    email = request.form.get('email')
    password = request.form.get('password')
    user = collection.find_one({"email": email, "password": password})

    if user:
        session['email'] = email
        return redirect(url_for('main_page', name=user['name']))
    else:
        return render_template('login.html', error='Invalid email or password')


@app.route('/main')
def main_page():
    name = request.args.get('name')
    return render_template('main_page.html', name=name)

    
@app.route('/get_otp', methods=['POST','GET'])
def get_otp():
    global otp
    otp = random.randint(1000, 9999)  # Example: 4-digit OTP
    print(otp)

    return render_template('otp_verification_page.html', otp = otp)

@app.route('/verify_otp', methods=['POST','GET'])
def verify_otp():
    global otp
    global user
    data = request.get_json()  # Parse JSON body
    otp_entered = data.get('otp_entered')

    if otp == otp_entered:
        return render_template('main_page.html', name=user['name'])
    else:
        return render_template('otp_verification_page.html', error='Invalid OTP')
    

@app.route('/start_test/distance_vision')
def distance_vision():
    return "Distance Vision Test Page"

@app.route('/start_test/near_vision')
def near_vision_language_select():
    # Renders language selection page
    return render_template('near_vision_language_select.html')


@app.route('/start_test/near_vision/<language>/<side>/<int:question>', methods=['GET', 'POST'])
def near_vision_test(language, side, question):
    if request.method == 'POST':
        data = request.get_json()
        points = data.get('points', 0)
        email = data.get('email')

        # Update MongoDB score for this side
        score_field = f"Near_vision_results.{side}_score"
        remark_field = f"Near_vision_results.{side}_remark"

        # Increment the score if needed (or you can sum later)
        user = collection.find_one({"email": email})
        current_score = user.get("Near_vision_results", {}).get(f"{side}_score", 0) if user else 0
        new_score = points

        # If last question for this side
        if question >= 6:
            remark = "Excellent" if new_score == 6 else "Needs Attention"
            collection.update_one(
                {"email": email},
                {"$set": {
                    score_field: new_score,
                    remark_field: remark
                }},
                upsert=True
            )
            if side == "right_eye":
                return jsonify({"message": "Right eye test done. Now test left eye.", "next": "left_eye"})
            else:
                return jsonify({"message": "Both eyes tested! Thanks!", "next": "done"})
        else:
            # Just return for next question
            collection.update_one(
                {"email": email},
                {"$set": {score_field: new_score}},
                upsert=True
            )
            return jsonify({"message": f"Proceed to question {question + 1}", "next": "next"})

    # GET request: render test page
    image_path = f"nv_{language.lower()}/image_{question}.png"


    # Correct answers per language + question
    correct_answers = {
        "English": {1: "bharat", 2: "anand", 3: "pooja", 4: "ahmed", 5: "netaji", 6: "nagpur"},
        "Tamil": {1: "பரத்", 2: "ஆனந்த்", 3: "பூஜா", 4: "அஹ்மத்", 5: "நிர்மல்", 6: "நாக்பூர்"},
        "Hindi": {1: "भारत", 2: "आनंद", 3: "पूजा", 4: "अहमद", 5: "नेताजी", 6: "नागपुर"},
        "Telugu": {1: "భారత్", 2: "ఆనంద్", 3: "పూజ", 4: "అహ్మద్", 5: "నేతాజీ", 6: "నాగపూర్"}
    }

    correct_answer = correct_answers.get(language, {}).get(question, "").strip()

    # Keypad letters for non-English
    keypad_letters = []
    if language != "English":
        unique = list(set(correct_answer))
        distractors = {
            "Tamil": ["அ", "ஆ", "இ", "ஈ", "உ", "க", "ங", "ச"],
            "Hindi": ["अ", "आ", "इ", "ई", "उ", "क", "ख", "ग"],
            "Telugu": ["అ", "ఆ", "ఇ", "ఈ", "ఉ", "క", "గ", "చ"]
        }
        pool = list(set(distractors.get(language, [])) - set(unique))
        import random
        random_distractors = random.sample(pool, min(12 - len(unique), len(pool)))
        keypad_letters = unique + random_distractors
        random.shuffle(keypad_letters)

    return render_template(
        'near_vision_test.html',
        language=language,
        side=side,
        question=question,
        image_path=image_path,
        correct_answer=correct_answer,
        email=session.get("email", ""),  # or pass email in another way
        keypad_letters=keypad_letters
    )





@app.route('/start_test/color_vision')
def color_vision_right():
    # Entry point → go directly to right eye test
    return redirect(url_for('color_vision_test', side='right_eye', question = 1))

@app.route('/start_test/color_vision/<side>/<int:question>', methods=['GET', 'POST'])
def color_vision_test(side, question):
    email = session.get('email')
    if not email:
        return redirect(url_for('index'))

    correct_answers = ['12', '8', '29', '5', '3', '15', '74', '6', '45', '5', '7', '16', '73', '', '', '26', '42']

    if request.method == 'POST':
        data = request.get_json()
        user_input = data.get('user_input', '').strip()
        points = 1 if user_input == correct_answers[question - 1] else 0

        collection.update_one(
            {"email": email},
            {"$inc": {f"Color_vision_results.{side}_score": points}},
            upsert=True
        )

        if question < 17:
            next_url = url_for('color_vision_test', side=side, question=question + 1)
            return jsonify({"next": next_url, "message": f"Saved Q{question}. Next question."})
        else:
            if side == 'right_eye':
                next_url = url_for('color_vision_test', side='left_eye', question=1)
                return jsonify({"next": next_url, "message": "Right eye done. Now left eye."})
            else:
                return jsonify({"next": url_for('score_page'), "message": "Test complete!"})

    image_path = f"pdf_images/page_{question}.png"
    correct_answer = correct_answers[question - 1]

    return render_template("color_vision_test.html",
                           image_path=image_path,
                           correct_answer=correct_answer,
                           side=side,
                           question=question,
                           email=email)




def determine_remark(score):
    if score > 11.7:
        return "excellent"
    elif score > 8.25:
        return "good"
    else:
        return "requires attention"

@app.route('/start_test/contrast_sensitivity')
def start_right_eye_test():
    # Entry point → go directly to right eye test
    return redirect(url_for('contrast_sensitivity_test', side='right_eye'))

@app.route('/start_test/contrast_sensitivity/<side>', methods=['GET', 'POST'])
def contrast_sensitivity_test(side):
    if side not in ['right_eye', 'left_eye']:
        return "Invalid side", 404

    email = session.get('email')
    if not email:
        return redirect(url_for('index'))  # Ensure user is logged in

    if request.method == 'POST':
        data = request.get_json()
        score = data.get('score')
        level = data.get('level')

        if score is None:
            return jsonify({'message': 'Missing score'}), 400

        remark = determine_remark(score)

        try:
            collection.update_one(
                {"email": email},
                {"$set": {
                    f"Contrast_sensitivity_results.{side}_score": score,
                    f"Contrast_sensitivity_results.{side}_remark": remark,
                    f"Contrast_sensitivity_results.{side}_level": level
                }},
                upsert=True
            )
            return jsonify({
                'message': f'{side.replace("_", " ").title()} result saved',
                'next': 'left_eye' if side == 'right_eye' else 'done'
            })
        except Exception as e:
            return jsonify({'message': f'Error saving result: {str(e)}'}), 500

    image_list = [f"contrast_images/page_{i}.png" for i in range(1, 17)]
    return render_template('contrast_test.html', side=side, images=image_list, email=email)


@app.route('/start_test/amsler_grid/<side>', methods=['GET', 'POST'])
def amsler_grid_test(side):
    if side not in ['right_eye', 'left_eye']:
        return "Invalid side", 404

    email = session.get('email')
    if not email:
        return redirect(url_for('index'))

    if request.method == 'POST':
        data = request.get_json()
        points = data.get('points')

        if points is None:
            return jsonify({'message': 'Missing points'}), 400

        # Determine remark
        remark = "excellent" if points == 6 else "requires attention"

        # Save to MongoDB
        try:
            collection.update_one(
                {"email": email},
                {
                    "$set": {
                        f"amsler_grid_test_results.{side}_score": points,
                        f"amsler_grid_test_results.{side}_remark": remark
                    }
                },
                upsert=True
            )

            # Determine next action
            next_step = 'left_eye' if side == 'right_eye' else 'done'
            return jsonify({
                'message': f"{side.replace('_', ' ').title()} result saved successfully.",
                'next': next_step
            })

        except Exception as e:
            return jsonify({'message': f"Error saving result: {str(e)}"}), 500

    # GET request → Render template
    return render_template('amsler_grid_test.html', side=side, email=email)


@app.route('/start_test/stereopsis')
def stereopsis():
    return "Stereopsis Test Page"

@app.route('/score')
def score_page():
    email = session.get('email')
    if not email:
        return redirect(url_for('index'))

    user = collection.find_one({"email": email})
    if not user:
        return "User data not found", 404

    return render_template('score_page.html', user=user)




if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)